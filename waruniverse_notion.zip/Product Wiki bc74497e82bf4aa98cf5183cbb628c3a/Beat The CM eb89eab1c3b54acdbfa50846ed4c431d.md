# Beat The CM

Owner: Artem AK

# **Rules and Basics**

In this event, players can participate in a battle against [CMs](https://www.notion.so/Staff-team-48f83f6794a244cbbfe6fc41554b9262?pvs=21) or [Admins](https://www.notion.so/Staff-team-48f83f6794a244cbbfe6fc41554b9262?pvs=21) on the X-2 Map (Duel map) to win rewards.

# **Important things to note**

- Fair play is important. Please mention in the chat after the fight, for example, "gf" or "gg."
- In general, CMs use [Perun](Perun%2062b2d856f0ab4c3799a080452848b7c9.md) with 8 [drones](Drones%2036b24832c354423db4310baf511712a7.md).
- Every [ammunition](Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08.md) type and all [extensions](Extensions%20ad99098f7be6439b877727e8069749b1.md) can be used.
- Every [drone cover](Drone%20Covers%20fe91ff98efef4ee58233886feac6b57b.md) can be used.
- Use the slow and speed [configuration](Speed%20Generators%20854e75ac1faa480284f7855de6261025.md) for your [Perun](Perun%2062b2d856f0ab4c3799a080452848b7c9.md) ship.

# **Conditions**

- To participate, players must submit their Player-ID through a ticket in the [WU-Discord](https://discord.com/invite/BpDcXZW) #get-support channel at least 15 minutes before the event starts.
- Players will fight against CMs based on the order of opened tickets.
- The event will last for an hour.
- If a player runs away from an opponent for more than 30 seconds, the fight ends.
- All players must use a [Perun](Perun%2062b2d856f0ab4c3799a080452848b7c9.md) ship with the [Speed](Speed%20Generators%20854e75ac1faa480284f7855de6261025.md)+[Slow](Shield%20Generators%20cf10852d8ed04fb08c52d19ff2b53284.md) configuration.
- The event and fights may be streamed on the WarUniverse Discord channel.
- If a player wins a fight, they will receive 50,000 PLT and one day of premium membership.
- To receive the reward, players need to keep the ticket open after winning the fight. An [Admin](https://www.notion.so/Staff-team-48f83f6794a244cbbfe6fc41554b9262?pvs=21) will add a notification in the ticket, and the reward will be given.