# Space Maps

Owner: Artem AK

![spacemap.png](Space%20Maps%203e361e362ddf4827bc4aa02a3d356cb2/spacemap.png)

The name of the maps like "X-1", "X-2", "X-3", etc. can be characterized as a general name, which refers to the cards of the same level.

In order to make it clear what are the cards with different designations:

[X-1 maps](Maps%20X-1%20de2a8dd8204249bcb3d4ff1442885009.md) are first-level cards that have the common name U-1, R-1, and E-1, depending on the type of card.

[X-2 maps](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md) are second-level cards that have the common name U-2, R-2, and E-2, depending on the card type.

[X-3 maps](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md) are third-level cards that have the common name U-3, R-3, and E-3, depending on the card type.

[J-XX maps](Maps%20J-XX%205d70b406baba46cfad632d4b75162fb7.md) are third-level cards that share the name J-VO, J-SO, and J-VS, depending on the card type.

[X-5 maps](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md) are fifth-level cards that have the common name U-5, R-5, and E-5, depending on the card type.

[X-6 maps](Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb.md) are six-level cards that share the name U-6, R-6, and E-6, depending on the card type.

[X-7 maps](Maps%20X-7%2047d1869952274ca4b56f277bfc6f7610.md) are seventh-level cards that have the common name U-7, R-7, and E-7, depending on the card type.

# **Orion Empire's Maps**

- E-1 (Base)
    
    **E-1** is the map of the Orion Empire.
    
    # **Aliens**
    
    - [Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md) - 40x
    - [Hyper Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md) - 7x
    
    # **Resources**
    
    - [Mercury](https://www.notion.so/Mercury-df3566ab61364070898b231e8f633a67?pvs=21)
    
    # **Portals**
    
    - Left Down: [E-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    - Right Down: [E-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md)
    
    # **Level Requirements**
    
    Orion Empire players require to be **Level 1** to access this map. Solar Conglomerate and Vega Union players require to be **Level 16** to invade this map.
    
- E-2
    
    **E-2** is the map of the Orion Empire.
    
    # **Aliens**
    
    - [Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md) - 25x
    - [Hyper Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md) - 7x
    - [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 20x
    - [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) x7
    
    # **Resources**
    
    - [Mercury](https://www.notion.so/Mercury-df3566ab61364070898b231e8f633a67?pvs=21)
    - [Erbium](https://www.notion.so/Erbium-bf095bb0b73d4d399f4a8be80da35c83?pvs=21)
    
    # **Portals**
    
    - Top Left: [E-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    - Right Middle: [E-1](Maps%20X-1%20de2a8dd8204249bcb3d4ff1442885009.md)
    - Bottom Middle: [J-SO](Maps%20J-XX%205d70b406baba46cfad632d4b75162fb7.md)
    
    # **Level Requirements**
    
    Orion Empire players require to be **Level 2** to access this map. Solar Conglomerate and Vega Union players require to be **Level 12** to invade this map.
    
- E-3
    
    **E-3** is the map of the Orion Empire.
    
    # **Aliens**
    
    - [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 20x
    - [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 4x
    - [Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 20x
    - [Hyper Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 4x
    - [Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 15x
    - [Hyper Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 4x
    - [Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 9x
    - [Hyper Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 3x
    
    # **Resources**
    
    - [Cerium](https://www.notion.so/Cerium-94559fad6493492cacc59395cad058e8?pvs=21)
    - [Piritid](https://www.notion.so/Piritid-88e209214cb4493eb5c9e89809df20a8?pvs=21)
    
    # **Portals**
    
    - Left Down: [T-1](Map%20T-1%20d3022dc7530045b2a4f7a5f807e617d1.md)
    - Top Left: [J-VO](Maps%20J-XX%205d70b406baba46cfad632d4b75162fb7.md)
    - Top Right: [E-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md)
    - Bottom Middle: [R-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    
    # **Level Requirements**
    
    Orion Empire players require to be **Level 3** to access this map. Solar Conglomerate and Vega Union players require to be **Level 7** to invade this map.
    
- J-VO
    
    **J-VO** is the map of Vega Union and Orion Empire.
    
    # **Aliens**
    
    - [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 25x
    - [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 6x
    - [Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 25x
    - [Hyper Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 6x
    - [Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 24x
    - [Hyper Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 6x
    - [Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 15x
    - [Hyper Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 6x
    - [Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 15x
    - [Hyper Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 5x
    
    # **Portals**
    
    - Top Right: [E-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    - Bottom Left: [U-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md)
    
    # **Special Events**
    
    - [Worm Hole](Wormhole%20b62fc31319c745d2a705a9102cc9ab87.md)
    
    # **Level Requirements**
    
    Vega Union and Orion Empire players require to be **Level 6** to access this map. Solar Conglomerate players require to be **Level 7** to invade this map.
    
- J-SO
    
    **J-SO** is the map of Solar Conglomerate and Orion Empire.
    
    # **Aliens**
    
    - [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 25x
    - [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 6x
    - [Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 25x
    - [Hyper Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 6x
    - [Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 24x
    - [Hyper Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 6x
    - [Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 15x
    - [Hyper Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 6x
    - [Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 15x
    - [Hyper Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 5x
    
    # **Portals**
    
    - Top Right: [E-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md)
    - Bottom Left: [R-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    
    # **Special Events**
    
    - [Worm Hole](Wormhole%20b62fc31319c745d2a705a9102cc9ab87.md)
    
    # **Level Requirements**
    
    Solar Conglomerate and Orion Empire players require to be **Level 6** to access this map. Vega Union players require to be **Level 7** to invade this map.
    
- E-5
    
    **E-5** is the map of the Orion Empire.
    
    # **Aliens**
    
    - [Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 30x
    - [Hyper Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 5x
    - [Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md) - 24x
    - [Hyper Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md) - 6x
    
    # **Portals**
    
    - Top Right: [E-6](Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb.md)
    - Right Middle: [E-7](Maps%20X-7%2047d1869952274ca4b56f277bfc6f7610.md)
    - Top Left: [G-1](Map%20G-1%20fb9f98f27cc144ff8b55ecbcc178722a.md)
    - Bottom Left: [T-1](Map%20T-1%20d3022dc7530045b2a4f7a5f807e617d1.md)
    
    # **Special Events**
    
    - [Group Mission](Group%20Mission%205731b02a8b944878af747efd2603fdca.md)
    - [Sector-18](Sector-18%2036c8628d052d48d88fce3337209dec1a.md)
    
    # **Level Requirements**
    
    Orion Empire players require to be **Level 10** to access this map. Solar Conglomerate and Vega Union players require to be **Level 13** to invade this map.
    
- E-6
    
    **E-6** is the map of the Orion Empire.
    
    # **Aliens**
    
    - [Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 30x
    - [Hyper Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 15x
    - [Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md) - 25x
    - [Hyper Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md) - 6x
    - [Quattroid](Quattroid%20884f394cf89d4978b6e7ed0489219510.md) - 2x
    
    # **Portals**
    
    - Top Right: [E-7](Maps%20X-7%2047d1869952274ca4b56f277bfc6f7610.md)
    - Bottom Left: [E-5](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md)
    
    # **Special Events**
    
    - [Worm Hole](Wormhole%20b62fc31319c745d2a705a9102cc9ab87.md)
    - [Free Pvp Tour](Free%20PVP%20Tour%200381f34fdecd4afa88f967b0d0e62391.md)
    
    # **Level Requirements**
    
    Orion Empire players require to be **Level 12** to access this map. Solar Conglomerate and Vega Union players require to be **Level 15** to invade this map.
    
- E-7 (Base)
    
    **E-7** is the map of the Orion Empire.
    
    # **Aliens**
    
    - [Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md) - 30x
    - [Hyper Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md) - 5x
    
    # **Portals**
    
    - Bottom Right: [E-5](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md)
    - Bottom Left: [E-6](Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb.md)
    
    # **Level Requirements**
    
    Orion Empire players require to be **Level 13** to access this map. Solar Conglomerate and Vega Union players require to be **Level 17** to invade this map.
    

# **Solar Conglomerate's Maps**

- R-1 (Base)
    
    **R-1** is the map of the Solar Conglomerate.
    
    # **Aliens**
    
    - [Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md) - 40x
    - [Hyper Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md) - 7x
    
    # **Resources**
    
    - [Mercury](https://www.notion.so/Mercury-df3566ab61364070898b231e8f633a67?pvs=21)
    
    # **Portals**
    
    - Top Left: [R-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    - Bottom Left: [R-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md)
    
    # **Level Requirements**
    
    Solar Conglomerate players require to be **Level 1** to access this map. Orion Empire and Vega Union players require to be **Level 16** to invade this map.
    
- R-2
    
    **R-2** is the map of the Solar Conglomerate.
    
    # **Aliens**
    
    - [Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md) - 25x
    - [Hyper Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md) - 7x
    - [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 20x
    - [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) x7
    
    # **Resources**
    
    - [Mercury](https://www.notion.so/Mercury-df3566ab61364070898b231e8f633a67?pvs=21)
    - [Erbium](https://www.notion.so/Erbium-bf095bb0b73d4d399f4a8be80da35c83?pvs=21)
    
    # **Portals**
    
    - Bottom Left: [J-VS](Maps%20J-XX%205d70b406baba46cfad632d4b75162fb7.md)
    - Bottom Right: [R-1](Maps%20X-1%20de2a8dd8204249bcb3d4ff1442885009.md)
    - Top Middle: [R-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    
    # **Level Requirements**
    
    Solar Conglomerate players require to be **Level 2** to access this map. Orion Empire and Vega Union players require to be **Level 12** to invade this map.
    
- R-3
    
    **R-3** is the map of the Solar Conglomerate.
    
    # **Aliens**
    
    - [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 20x
    - [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 4x
    - [Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 20x
    - [Hyper Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 4x
    - [Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 15x
    - [Hyper Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 4x
    - [Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 9x
    - [Hyper Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 3x
    
    # **Resources**
    
    - [Cerium](https://www.notion.so/Cerium-94559fad6493492cacc59395cad058e8?pvs=21)
    - [Piritid](https://www.notion.so/Piritid-88e209214cb4493eb5c9e89809df20a8?pvs=21)
    
    # **Portals**
    
    - Top Left: [E-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    - Top Right: [J-S0](Maps%20J-XX%205d70b406baba46cfad632d4b75162fb7.md)
    - Top Middle: [T-1](Map%20T-1%20d3022dc7530045b2a4f7a5f807e617d1.md)
    - Bottom Right: [R-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md)
    - Left Middle: [U-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    
    # **Level Requirements**
    
    Solar Conglomerate players require to be **Level 3** to access this map. Orion Empire and Vega Union players require to be **Level 7** to invade this map.
    
- J-VS
    
    **J-VS** is the map of Vega Union and Solar Conglomerate.
    
    # **Aliens**
    
    - [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 25x
    - [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 6x
    - [Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 25x
    - [Hyper Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 6x
    - [Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 24x
    - [Hyper Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 6x
    - [Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 15x
    - [Hyper Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 6x
    - [Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 15x
    - [Hyper Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 5x
    
    # **Portals**
    
    - Top Left: [U-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    - Bottom Right: [R-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md)
    
    # **Special Events**
    
    - [Worm Hole](Wormhole%20b62fc31319c745d2a705a9102cc9ab87.md)
    
    # **Level Requirements**
    
    Vega Union and Solar Conglomerate. players require to be **Level 6** to access this map. Orion Empire players require to be **Level 7** to invade this map.
    
- J-SO
    
    **J-SO** is the map of Solar Conglomerate and Orion Empire.
    
    # **Aliens**
    
    - [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 25x
    - [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 6x
    - [Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 25x
    - [Hyper Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 6x
    - [Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 24x
    - [Hyper Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 6x
    - [Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 15x
    - [Hyper Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 6x
    - [Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 15x
    - [Hyper Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 5x
    
    # **Portals**
    
    - Top Right: [E-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md)
    - Bottom Left: [R-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    
    # **Special Events**
    
    - [Worm Hole](Wormhole%20b62fc31319c745d2a705a9102cc9ab87.md)
    
    # **Level Requirements**
    
    Solar Conglomerate and Orion Empire players require to be **Level 6** to access this map. Vega Union players require to be **Level 7** to invade this map.
    
- R-5
    
    **R-5** is the map of the Solar Conglomerate.
    
    # **Aliens**
    
    - [Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 30x
    - [Hyper Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 5x
    - [Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md) - 24x
    - [Hyper Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md) - 6x
    
    # **Portals**
    
    - Top Middle: [R-6](Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb.md)
    - Top Left: [R-7](Maps%20X-7%2047d1869952274ca4b56f277bfc6f7610.md)
    - Bottom Left: [G-1](Map%20G-1%20fb9f98f27cc144ff8b55ecbcc178722a.md)
    - Bottom Right: [T-1](Map%20T-1%20d3022dc7530045b2a4f7a5f807e617d1.md)
    
    # **Special Events**
    
    - [Group Mission](Group%20Mission%205731b02a8b944878af747efd2603fdca.md)
    - [Sector-18](Sector-18%2036c8628d052d48d88fce3337209dec1a.md)
    
    # **Level Requirements**
    
    Solar Conglomerate players require to be **Level 10** to access this map. Orion Empire and Vega Union players require to be **Level 13** to invade this map.
    
- R-6
    
    **R-6** is the map of the Solar Conglomerate.
    
    # **Aliens**
    
    - [Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 30x
    - [Hyper Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 15x
    - [Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md) - 25x
    - [Hyper Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md) - 6x
    - [Quattroid](Quattroid%20884f394cf89d4978b6e7ed0489219510.md) - 2x
    
    # **Portals**
    
    - Top Left: [R-7](Maps%20X-7%2047d1869952274ca4b56f277bfc6f7610.md)
    - Bottom Right: [R-5](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md)
    
    # **Special Events**
    
    - [Worm Hole](Wormhole%20b62fc31319c745d2a705a9102cc9ab87.md)
    - [Free Pvp Tour](Free%20PVP%20Tour%200381f34fdecd4afa88f967b0d0e62391.md)
    
    # **Level Requirements**
    
    Solar Conglomerate players require to be **Level 12** to access this map. Orion Empire and Vega Union players require to be **Level 15** to invade this map.
    
- R-7 (Base)
    
    **R-7** is the map of the Solar Conglomerate.
    
    # **Aliens**
    
    - [Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md) - 30x
    - [Hyper Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md) - 5x
    
    # **Portals**
    
    - Top Right: [R-6](Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb.md)
    - Bottom Right: [R-5](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md)
    
    # **Level Requirements**
    
    Solar Conglomerate players require to be **Level 13** to access this map. Orion Empire and Vega Union players require to be **Level 17** to invade this map.
    

# **Vega Union's Maps**

- U-1 (Base)
    
    **U-1** is the map of the Vega Union.
    
    # **Aliens**
    
    - [Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md) - 40x
    - [Hyper Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md) - 7x
    
    # **Resources**
    
    - [Mercury](https://www.notion.so/Mercury-df3566ab61364070898b231e8f633a67?pvs=21)
    
    # **Portals**
    
    - Top Left: [U-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md)
    - Bottom Right: [U-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    
    # **Level Requirements**
    
    Vega Union players require to be **Level 1** to access this map. Solar Conglomerate and Orion Empire players require to be **Level 16** to invade this map.
    
- U-2
    
    **U-2** is the map of the Vega Union.
    
    # **Aliens**
    
    - [Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md) - 25x
    - [Hyper Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md) - 7x
    - [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 20x
    - [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) x7
    
    # **Resources**
    
    - [Mercury](https://www.notion.so/Mercury-df3566ab61364070898b231e8f633a67?pvs=21)
    - [Erbium](https://www.notion.so/Erbium-bf095bb0b73d4d399f4a8be80da35c83?pvs=21)
    
    # **Portals**
    
    - Bottom Left: [U-1](Maps%20X-1%20de2a8dd8204249bcb3d4ff1442885009.md)
    - Bottom Right: [U-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    - Top Right: [J-VO](Maps%20J-XX%205d70b406baba46cfad632d4b75162fb7.md)
    
    # **Level Requirements**
    
    Vega Union players require to be **Level 2** to access this map. Solar Conglomerate and Orion Empire players require to be **Level 12** to invade this map.
    
- U-3
    
    **U-3** is the map of the Vega Union.
    
    # **Aliens**
    
    - [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 20x
    - [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 4x
    - [Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 20x
    - [Hyper Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 4x
    - [Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 15x
    - [Hyper Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 4x
    - [Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 9x
    - [Hyper Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 3x
    
    # **Resources**
    
    - [Cerium](https://www.notion.so/Cerium-94559fad6493492cacc59395cad058e8?pvs=21)
    - [Piritid](https://www.notion.so/Piritid-88e209214cb4493eb5c9e89809df20a8?pvs=21)
    
    # **Portals**
    
    - Top Left: [U-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md)
    - Top Right: [T-1](Map%20T-1%20d3022dc7530045b2a4f7a5f807e617d1.md)
    - Right Middle: [R-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    - Bottom Right: [J-VS](Maps%20J-XX%205d70b406baba46cfad632d4b75162fb7.md)
    
    # **Level Requirements**
    
    Vega Union players require to be **Level 3** to access this map. Orion Empire and Solar Conglomerate players require to be **Level 7** to invade this map.
    
- J-VS
    
    **J-VS** is the map of Vega Union and Solar Conglomerate.
    
    # **Aliens**
    
    - [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 25x
    - [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 6x
    - [Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 25x
    - [Hyper Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 6x
    - [Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 24x
    - [Hyper Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 6x
    - [Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 15x
    - [Hyper Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 6x
    - [Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 15x
    - [Hyper Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 5x
    
    # **Portals**
    
    - Top Left: [U-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    - Bottom Right: [R-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md)
    
    # **Special Events**
    
    - [Worm Hole](Wormhole%20b62fc31319c745d2a705a9102cc9ab87.md)
    
    # **Level Requirements**
    
    Vega Union and Solar Conglomerate. players require to be **Level 6** to access this map. Orion Empire players require to be **Level 7** to invade this map.
    
- J-VO
    
    **J-VO** is the map of Vega Union and Orion Empire.
    
    # **Aliens**
    
    - [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 25x
    - [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 6x
    - [Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 25x
    - [Hyper Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 6x
    - [Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 24x
    - [Hyper Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 6x
    - [Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 15x
    - [Hyper Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 6x
    - [Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 15x
    - [Hyper Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 5x
    
    # **Portals**
    
    - Top Right: [E-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    - Bottom Left: [U-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md)
    
    # **Special Events**
    
    - [Worm Hole](Wormhole%20b62fc31319c745d2a705a9102cc9ab87.md)
    
    # **Level Requirements**
    
    Vega Union and Orion Empire players require to be **Level 6** to access this map. Solar Conglomerate players require to be **Level 7** to invade this map.
    
- U-5
    
    **U-5** is the map of the Vega Union.
    
    # **Aliens**
    
    - [Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 30x
    - [Hyper Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 5x
    - [Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md) - 24x
    - [Hyper Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md) - 6x
    
    # **Portals**
    
    - Top Right: [T-1](Map%20T-1%20d3022dc7530045b2a4f7a5f807e617d1.md)
    - Top Left: [G-1](Map%20G-1%20fb9f98f27cc144ff8b55ecbcc178722a.md)
    - Bottom Left: [U-7](Maps%20X-7%2047d1869952274ca4b56f277bfc6f7610.md)
    - Right Middle: [U-6](Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb.md)
    
    # **Special Events**
    
    - [Group Mission](Group%20Mission%205731b02a8b944878af747efd2603fdca.md)
    - [Sector-18](Sector-18%2036c8628d052d48d88fce3337209dec1a.md)
    
    # **Level Requirements**
    
    Vega Union players require to be **Level 10** to access this map. Orion Empire and Solar Conglomerate players require to be **Level 13** to invade this map.
    
- U-6
    
    **U-6** is the map of the Vega Union.
    
    # **Aliens**
    
    - [Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 30x
    - [Hyper Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 15x
    - [Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md) - 25x
    - [Hyper Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md) - 6x
    - [Quattroid](Quattroid%20884f394cf89d4978b6e7ed0489219510.md) - 2x
    
    # **Portals**
    
    - Left Middle: [U-7](Maps%20X-7%2047d1869952274ca4b56f277bfc6f7610.md)
    - Right Middle: [U-5](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md)
    
    # **Special Events**
    
    - [Worm Hole](Wormhole%20b62fc31319c745d2a705a9102cc9ab87.md)
    - [Free Pvp Tour](Free%20PVP%20Tour%200381f34fdecd4afa88f967b0d0e62391.md)
    
    # **Level Requirements**
    
    Vega Union players require to be **Level 12** to access this map. Orion Empire and Solar Conglomerate players require to be **Level 15** to invade this map.
    
- U-7 (Base)
    
    **U-7** is the map of the Vega Union.
    
    # **Aliens**
    
    - [Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md) - 30x
    - [Hyper Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md) - 5x
    
    # **Portals**
    
    - Bottom Right: [U-5](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md)
    - Top Right: [U-6](Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb.md)
    
    # **Level Requirements**
    
    Vega Union players require to be **Level 13** to access this map. Solar Conglomerate and Orion Empire players require to be **Level 17** to invade this map.
    

# **Others**

- T-1
    
    It does not belong to any factions.
    
    # **Aliens**
    
    There are no aliens on the map.
    
    # **Portals**
    
    - Top: [R-5](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md)
    - Right: [E-5](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md)
    - Left: [U-5](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md)
    
    ### **Bottom Portals**
    
    - Top: [R-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    - Right: [E-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    - Left: [U-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
    
    # **Special Events**
    
    - [Checkout](Checkout%20ab26166aec554117b5ef3d2afd23fabd.md)
    - [Spaceball](Spaceball%20Gball%2041a8d2a2fd0b40319d2820359a751c9c.md)
    
    # **Level Requirements**
    
    Solar Conglomerate, Orion Empire and Vega Union players require to be **Level 9** to access this map.
    
- G-1
    
    It does not belong to any factions.
    
    # **Aliens**
    
    - [Ultra Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md) - 10x
    - [Ultra Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 10x
    - [Ultra Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 10x
    - [Ultra Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 10x
    - [Ultra Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 8x
    - [Ultra Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 10x
    - [Ultra Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md) - 8x
    - [Ultra Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md) - 8x
    - [Ultra Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md) - 10x
    - [Hyper Quattroid](Quattroid%20884f394cf89d4978b6e7ed0489219510.md) - 1x
    - [Ultra Quattroid](Quattroid%20884f394cf89d4978b6e7ed0489219510.md) - 1x
    - [Ultra Mortron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 8x
    
    # **Portals**
    
    - Middle : [T-1](Map%20T-1%20d3022dc7530045b2a4f7a5f807e617d1.md)
    - Other Portals : [G-1](Map%20G-1%20fb9f98f27cc144ff8b55ecbcc178722a.md) Middle Portal
    
    # **Special Events**
    
    - [Spaceball](Spaceball%20Gball%2041a8d2a2fd0b40319d2820359a751c9c.md)
    
    # **Level Requirements**
    
    Solar Conglomerate, Orion Empire and Vega Union players require to be **Level 11** to access this map.