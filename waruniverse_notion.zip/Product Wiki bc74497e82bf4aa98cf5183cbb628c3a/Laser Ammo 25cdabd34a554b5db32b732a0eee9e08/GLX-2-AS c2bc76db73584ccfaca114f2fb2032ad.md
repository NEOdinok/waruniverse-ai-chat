# GLX-2-AS

Owner: Tizian Fl

# **GLX-2-AS**

![**GLX-2-AS**](1lammo5.png)

**GLX-2-AS**

Unlike other laser ammo, GLX-2-AS does not cause normal damage to the target's HP; instead, it drains the target's shields and refills the shooter's shields. The amount of shield it drains is comparable to BLX-3.

## ****Obtaining****

- Ammunition (in Shop )
- Picking it up from a [bonus box](https://www.notion.so/Bonus-Boxes-056ed167ee5748ef8dbb2660e2195fde?pvs=21).
- Spinning (in Star Missions)
- Completing a quest and receiving it as a reward.
- Gold Market
    - Rush Hour Supply Package