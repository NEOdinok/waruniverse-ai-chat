# Group Mission

Owner: Artem AK

![Group_mission.png](Group%20Mission%205731b02a8b944878af747efd2603fdca/Group_mission.png)

Event starts on [X-5](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md) maps of each [faction](War%20Of%20Factions%208bce5de278f94db7a0f9667c8d01fbbc.md). After Group Missions are activated there will be a wave of [aliens](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) similar to the [Star Missions](https://www.notion.so/Star-Missions-6c41438d8de04d0294a3d1af4705ec6f?pvs=21) waves, after defeating all aliens from the wave the next one will start. Each alien is two times stronger than their regular variant and they are visible throughout the whole map, marked with yellow colour unlike regular aliens or enemies. All rewards from the aliens attacking during the waves is shared between players who fought them and divided depending on the damage dealt.

# **Rewards**

1 Point = 24 PLT, 48 HNR, 500 EXP

- 1st Faction Players -> 50% bonus
- 1st Player -> 100% bonus