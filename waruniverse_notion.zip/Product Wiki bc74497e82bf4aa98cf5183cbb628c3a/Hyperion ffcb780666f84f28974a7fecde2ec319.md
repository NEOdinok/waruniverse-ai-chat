# Hyperion

Owner: Artem AK

![**Hyperion**](Hyperion%20ffcb780666f84f28974a7fecde2ec319/Hyperion.png)

**Hyperion**

One of the best ships for killing NPCs. It has a great advantage thanks to its large number of slots for generators, weapons, and a large cargo. It can also be won at [auction](Auction%2089a99a098f044657a6a7d6c12227b32b.md).

| Price | 120.000 PLT |
| --- | --- |
| Hitpoints | 296.000 |
| Speed | 300 |
| Laser%20Guns%200627e2c86ab34b61bb757005554f45a8.md | 16 |
| Shield%20Generators%20cf10852d8ed04fb08c52d19ff2b53284.md | 16 |
| Extensions%20ad99098f7be6439b877727e8069749b1.md | 5 |
| Cargo | 3000 |