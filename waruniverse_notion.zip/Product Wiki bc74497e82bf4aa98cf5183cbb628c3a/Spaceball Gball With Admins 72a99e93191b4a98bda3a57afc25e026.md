# Spaceball/Gball With Admins

Owner: Artem AK

# **Rules and basics**

Each faction will have its own [administrator](https://www.notion.so/Staff-team-48f83f6794a244cbbfe6fc41554b9262?pvs=21) to participate in the event.

# **Important things to note**

- The [administrator](https://www.notion.so/Staff-team-48f83f6794a244cbbfe6fc41554b9262?pvs=21) must use the Hyperion-Adm ship during the event with the basic amount of HP.
- The objective of the event is to have the [administrator](https://www.notion.so/Staff-team-48f83f6794a244cbbfe6fc41554b9262?pvs=21) fight against players from the opposing faction while staying close to their own company's ball.
- The [administrator](https://www.notion.so/Staff-team-48f83f6794a244cbbfe6fc41554b9262?pvs=21) can use any available [ammunition](Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08.md), [extensions](Extensions%20ad99098f7be6439b877727e8069749b1.md), and [drone covers](Drone%20Covers%20fe91ff98efef4ee58233886feac6b57b.md) during the event, but shooting the ball is not allowed.
- The goal of the event is to support one's own faction rather than solely focusing on defeating the enemy. It's not about hunting down as many players as possible.