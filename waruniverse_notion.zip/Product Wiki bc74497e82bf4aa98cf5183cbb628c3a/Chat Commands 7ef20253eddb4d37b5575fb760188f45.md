# Chat Commands

Owner: Artem AK

# **[Carrier](https://waruniverse.fandom.com/wiki/Carrier) Commands**

| !use | command used for using the https://waruniverse.fandom.com/wiki/Carrier (https://www.youtube.com/watch?v=hanXdZk-SYA) |
| --- | --- |
| !aim | command for aiming bombers launched by https://waruniverse.fandom.com/wiki/Carrier (https://www.youtube.com/watch?v=hanXdZk-SYA) |
| !shot | command for launching https://waruniverse.fandom.com/wiki/Carrier (https://www.youtube.com/watch?v=hanXdZk-SYA) |

# **Promo Codes**

| !ezstart wustart | When you type in any chat, you will earn 700 https://www.notion.so/Game-Shop-a1a80d72f8b34b8fa3c8bf5eeabf90a0?pvs=21 for 1-10 level accounts.The code can only be used once per account. |
| --- | --- |