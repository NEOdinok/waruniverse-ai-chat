# Free PVP Tour

Owner: Artem AK

![Freepvptour.png](Free%20PVP%20Tour%200381f34fdecd4afa88f967b0d0e62391/Freepvptour.png)

There will be no consumption of Laser, Rocket or Energy ammunition!

Free PVP Tour is a regular event happening at Weekends from Friday 12:00 CEST until Monday 12:00 CEST. To participate, simply navigate your spaceship to the middle of U-6, R-6 or E-6 map. There will be special portal to PvP-1 map.

At this map you can shoot your own faction members, launch Bombers with Carrier, top up resources in your cargo and much more!

Maybe, you will be lucky to meet some admins whom you could defeat

### **Important details**

- After destruction ship will be respawned at the same (PVP-1) map. If you want, you could leave at any moment by jumping to one of 3 faction-specific portals.
- While being at PvP-1 map your ammunition is not being consumed.
- But you also do not receive any score points or reward for destruction of other ships.
- Pay attention that resources like Dungid and Xureon are still being consumed. It is not a problem, you can fill your tanks near one of 8 Yummy Towers located at the middle of the map.
- Also, please note, that without Premium, ship repair costs 500 PLT.