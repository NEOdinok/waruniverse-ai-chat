# Coffin Boxes (Halloween Special)

Owner: Tizian Fl

The **Coffin Boxes** can be found at Halloween events. They contain more rewards than regular bonus boxes and can be collected on the cosmic map.

**Reward:** 

→ Coffin Boxes contain **ten times** as many rewards as regular [Bonus Boxes](Bonus%20Boxes%2094c2b5da79794555bc374653848d0650.md).

**Location:**

→ They can be collected on the [G-1 map](../Map%20G-1%20fb9f98f27cc144ff8b55ecbcc178722a.md).

→ They also appear in **large numbers** in the [Checkout Event](../Checkout%20ab26166aec554117b5ef3d2afd23fabd.md) on the [T-1 Map](../Map%20T-1%20d3022dc7530045b2a4f7a5f807e617d1.md).