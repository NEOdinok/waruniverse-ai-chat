# Pumpkin Boxes (Halloween Special)

Owner: Tizian Fl

The Pumpkin Boxes can be found at Halloween events. They contain more rewards than regular bonus boxes and can be collected on the cosmic map.

**Reward:** 

→ Coffin Boxes contain **three times** as many rewards as regular [Bonus Boxes](Bonus%20Boxes%2094c2b5da79794555bc374653848d0650.md).

**Location:**

→ They can be collected on the [X-3](../Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md) and [X-5](../Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md) maps.