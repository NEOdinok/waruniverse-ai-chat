# Green Boxes

Owner: Tizian Fl

The green boxes aren’t regular [bonus boxes](Bonus%20Boxes%2094c2b5da79794555bc374653848d0650.md). They're so unique that they just appear if you beat some of the hardest enemies in the game!

**Which enemies do I have to destroy, and where do I find the boxes?**

- [X-5 Maps](../Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md): [Bangoliour](../Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md), [Hyper Bangoliour](../Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md), [Zavientos](../Zavientos%20a28be49b66384a719093c6336f20c866.md), [Hyper Zavientos](../Zavientos%20a28be49b66384a719093c6336f20c866.md)
- [X-6 Maps](../Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb.md): [Bangoliour](../Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md), [Hyper Bangoliour](../Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md), [Magmius](../Magmius%20ca4841e944cc4776b860f60d632297e8.md), [Hyper Magmius](../Magmius%20ca4841e944cc4776b860f60d632297e8.md), [Vortex](../Vortex%201def8df83c27449e9b924343ad8224f3.md), [Quattroid](../Quattroid%20884f394cf89d4978b6e7ed0489219510.md)
- [X-7 Maps](../Maps%20X-7%2047d1869952274ca4b56f277bfc6f7610.md): [Raider](../Raider%2049d85c720db14b09a19c6fd7a8b10415.md), [Hyper Raider](../Raider%2049d85c720db14b09a19c6fd7a8b10415.md)
- [G-1 Map](../Map%20G-1%20fb9f98f27cc144ff8b55ecbcc178722a.md): [All Ultra Aliens](../Map%20G-1%20fb9f98f27cc144ff8b55ecbcc178722a.md), [Hyper Vortex](../Vortex%201def8df83c27449e9b924343ad8224f3.md), [Hyper Quattroid](../Quattroid%20884f394cf89d4978b6e7ed0489219510.md)

**Special Droprates**

- When a [Quattroid](../Quattroid%20884f394cf89d4978b6e7ed0489219510.md) is destroyed, it drops **two** green boxes.
- When an [Hyper Quattroid](../Quattroid%20884f394cf89d4978b6e7ed0489219510.md) is destroyed, it drops **four** green boxes.
- When an [Ultra Quattroid](../Quattroid%20884f394cf89d4978b6e7ed0489219510.md) is destroyed, it drops **eight** green boxes.

**How can I open the green boxes?**  

Unlike the normal [bonus boxes](Bonus%20Boxes%2094c2b5da79794555bc374653848d0650.md), you need a **[green key](../Green%20Keys%20968b4902ea5d4ac58bc6cf15302145bc.md)** for the green boxes, to be able to open it.

### **Possible rewards from the green boxes:**

**Laser guns**

- [LG-4](../Laser%20Guns%200627e2c86ab34b61bb757005554f45a8/LG-4%20222acfcdc0834fa7b4c32a317a9f79e6.md)
- [LG-3](../Laser%20Guns%200627e2c86ab34b61bb757005554f45a8/LG-3%2079c1e4cdac494d4b8ef9082dfdef781b.md)

**Shield generator**

- [SG-3](../Shield%20Generators%20cf10852d8ed04fb08c52d19ff2b53284/SG-3%2018ae552c7d2d4a8c9d4e4e6c78e3b11f.md)

**Speed generator**

- [ACC-3](../Speed%20Generators%20854e75ac1faa480284f7855de6261025/ACC-3%20df796c838e8a405696ea2302221143e1.md)

**Laser ammunition**

- [BLX-3](../Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08/BLX-3%20ed3d3dc2f6e8403ab18d2583536938d6.md)
- [WLX-4](../Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08/WLX-4%20ee56ac0c96e34d6ca005df782840cd54.md)
- [GLX-2-AS](../Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08/GLX-2-AS%20c2bc76db73584ccfaca114f2fb2032ad.md)
- [MRS-6X](../Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08/MRS-6X%20d05becadb7e049e1b97665fa3b72098e.md)

**Rocket ammunition**

- [TNC-130](../Rocket%20Ammo%20294a05bce70947eea43013d15afabf9d/TNC-130%20c1428b283d6846a5827b920c08cc6d19.md)

**Energy ammunition**

- [EE-1](../Energy%20Ammo%2035eb07f6e4704660acb8b47ce014fec2/EE-1%2068fceefbaf3c43909d2ce2cc6af0c17e.md)
- [EN-702](../Energy%20Ammo%2035eb07f6e4704660acb8b47ce014fec2/EN-702%2080f8d16883d34554aac2829e06367413.md)
- [EG-88-3](../Energy%20Ammo%2035eb07f6e4704660acb8b47ce014fec2/EG-88-3%20d06b6834090649bfae7504551f306bef.md)
- [EM-AP-4](../Energy%20Ammo%2035eb07f6e4704660acb8b47ce014fec2/EM-AP-4%205134b02b004b40109fc706a313fd98ab.md)