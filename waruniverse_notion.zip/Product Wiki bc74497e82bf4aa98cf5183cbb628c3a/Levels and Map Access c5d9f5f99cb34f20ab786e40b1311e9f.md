# Levels and Map Access

Owner: Artem AK

|  | Experience | Access to ally maps | Access to enemy maps |
| --- | --- | --- | --- |
| Level 1 | 0 | Access to Maps%20X-1%20de2a8dd8204249bcb3d4ff1442885009.md map | - |
| Level 2 | 10.000 | Access to Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md map | - |
| Level 3 | 20.000 | - | - |
| Level 4 | 40.000 | Access to Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md map | - |
| Level 5 | 80.000 | - | - |
| Level 6 | 160.000 | Access to Maps%20J-XX%205d70b406baba46cfad632d4b75162fb7.md map | Access to Maps%20J-XX%205d70b406baba46cfad632d4b75162fb7.md and Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md maps |
| Level 7 | 320.000 | - | - |
| Level 8 | 640.000 | - | - |
| Level 9 | 1.280.000 | Access to Map%20T-1%20d3022dc7530045b2a4f7a5f807e617d1.md map | Access to Map%20T-1%20d3022dc7530045b2a4f7a5f807e617d1.md map |
| Level 10 | 2.560.000 | Access to Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md map | - |
| Level 11 | 5.120.000 | Access to Map%20G-1%20fb9f98f27cc144ff8b55ecbcc178722a.md map | Access to Map%20G-1%20fb9f98f27cc144ff8b55ecbcc178722a.md map |
| Level 12 | 10.240.000 | Access to Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb.md map | Access to Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md map |
| Level 13 | 20.480.000 | Access to Maps%20X-7%2047d1869952274ca4b56f277bfc6f7610.md map | Access to Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md map |
| Level 14 | 40.960.000 | - | - |
| Level 15 | 80.192.000 | - | Access to Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb.md map |
| Level 16 | 160.384.000 | - | Access to Maps%20X-1%20de2a8dd8204249bcb3d4ff1442885009.md map |
| Level 17 | 320.768.000 | Full access to WarUniverse | Full access to WarUniverse |
| Level 18 | 641.536.000 | Full access to WarUniverse | Full access to WarUniverse |
| Level 19 | 1.283.072.000 | Full access to WarUniverse | Full access to WarUniverse |
| Level 20 | 2.566.144.000 | Full access to WarUniverse | Full access to WarUniverse |
| Level 21 | 5.132.288.000 | Full access to WarUniverse | Full access to WarUniverse |
| Level 22 | 10.264.576.000 | Full access to WarUniverse | Full access to WarUniverse |
| Level 23 | 20.529.152.000 | Full access to WarUniverse | Full access to WarUniverse |
| Level 24 | 41.058.304.000 | Full access to WarUniverse | Full access to WarUniverse |