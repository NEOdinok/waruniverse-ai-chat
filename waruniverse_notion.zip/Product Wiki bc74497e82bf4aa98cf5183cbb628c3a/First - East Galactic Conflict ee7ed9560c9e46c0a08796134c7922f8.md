# First - East Galactic Conflict

Owner: Artem AK

![East.png](First%20-%20East%20Galactic%20Conflict%20ee7ed9560c9e46c0a08796134c7922f8/East.png)

Our faction has a big problem on the East side of the Galaxy. Try to resolve it.

# **Requirements**

East Galactic Conflict requires **74** parameters to be built

# **Waves**

### **Wave 1**

40х[Ultra Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md)

### **Wave 2**

40х[Ultra Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md)

### **Wave 3**

40х[Ultra Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md)

### **Wave 4**

40х[Ultra Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md)

### **Wave 5**

20х[Ultra Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md)

### **Wave 6**

15х[Ultra Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md)

### **Wave 7**

15х[Ultra Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md), 10х[Ultra Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md), 5х[Ultra Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md), 3х[Ultra Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md), 2х[Ultra Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) and 1х[Ultra Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md)

### **Wave 8**

40х[Ultra Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md)

### **Wave 9**

10х[Ultra Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md)

### **Wave 10**

10х[Ultra Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md)

### **Wave 11**

6х[Ultra Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md), 2х[Ultra Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md) and 1х[Ultra Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md)

### **Wave 12**

25х[Ultra Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md)

### **Wave 13**

25х[Ultra Vortex](Vortex%201def8df83c27449e9b924343ad8224f3.md)

### **Wave 14**

5х[Ultra Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md), 5х[Ultra Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md), 5х[Ultra Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md), 3х[Ultra Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md), 2х[Ultra Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md), 1х[Ultra Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md), 1х[Ultra Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md), 1х[Ultra Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md), 1х[Ultra Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md), 1х[Ultra Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md) and 1х[Ultra Vortex](Vortex%201def8df83c27449e9b924343ad8224f3.md)

# Rewards

| Experience | 12.000.000 |
| --- | --- |
| Honor | 300.000 |
| Platinum | 75.000 |
| https://www.notion.so/WLX-4-7aca22a0c0374b07ae58b44741c35272?pvs=21 | 120.000 |
| Drone%20Covers%20fe91ff98efef4ee58233886feac6b57b/DCD%204511c751938e458682483f647dbe596d.md | 1 |