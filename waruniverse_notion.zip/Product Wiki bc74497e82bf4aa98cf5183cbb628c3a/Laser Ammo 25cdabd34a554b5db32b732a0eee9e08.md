# Laser Ammo

Owner: Artem AK

# **RLX-1**

![**RLX-1**](Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08/1lammo1.png)

**RLX-1**

RLX-1 is BTC bought laser ammunation which is currently the least powerful ammunition for laser guns dealing x1 (so regular) amounts of damage.

## ****Obtaining****

- Ammunition (in Shop )
- Picking it up from a [bonus box](Boxes%2093ebc4bf4cc54122b18f3099e005047b.md).

# ****GLX-2****

![**GLX-2**](Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08/1lammo2.png)

**GLX-2**

GLX-2 is one step up from Red Ammunition, dealing twice its damage.

## ****Obtaining****

- Ammunition (in Shop )
- Picking it up from a [bonus box](Boxes%2093ebc4bf4cc54122b18f3099e005047b.md).
- Completing a quest and receiving it as a reward.

# **BLX-3**

![**BLX-3**](Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08/1lammo3.png)

**BLX-3**

BLX-3 deals triple damage.

## ****Obtaining****

- Ammunition (in Shop )
- Picking it up from a [bonus box](Boxes%2093ebc4bf4cc54122b18f3099e005047b.md).
- Spinning (in Star Missions)

# **WLX-4**

![**WLX-4**](Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08/1lammo4.png)

**WLX-4**

WLX-4 deals quadruple damage.

## ****Obtaining****

- Picking it up from a [bonus box](https://www.notion.so/Bonus-Boxes-056ed167ee5748ef8dbb2660e2195fde?pvs=21). (G-1 map)
- Spinning (in [Star Missions](https://www.notion.so/Star-Missions-Overview-9cd4528c705c467d8df770096c2b4cc4?pvs=21))
- Completing a [Star Mission](https://www.notion.so/Star-Missions-Overview-9cd4528c705c467d8df770096c2b4cc4?pvs=21) and receiving it as a reward.
- Completing a quest and receiving it as a reward.
- Destroying Ultra [NPC](https://www.notion.so/Magmius-447a74b14de249b1bbad9763dd8c2371?pvs=21) and receiving it as a reward.
- Gold Market
    - Rush Hour Supply Package
    - Combat Supply Package

# **GLX-2-AS**

![**GLX-2-AS**](Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08/1lammo5.png)

**GLX-2-AS**

Unlike other laser ammo, GLX-2-AS does not cause normal damage to the target's HP; instead, it drains the target's shields and refills the shooter's shields. The amount of shield it drains is comparable to BLX-3.

## ****Obtaining****

- Ammunition (in Shop )
- Picking it up from a [bonus box](Boxes%2093ebc4bf4cc54122b18f3099e005047b.md).
- Spinning (in Star Missions)
- Completing a quest and receiving it as a reward.
- Gold Market
    - Rush Hour Supply Package

# **MRS-6X**

![**MRS-6X**](Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08/1lammo6.png)

**MRS-6X**

MRS-6X is a type of ammunition that gives 6 times the damage but has a brief cooldown after each use. For this reason it is usually combined with another ammo type.

## ****Obtaining****

- Ammunition (in Shop )
- Completing a quest and receiving it as a reward.
- Gold Market
    - Combat Supply Package
    - Rush Hour Supply Package

[**RLX-1**](Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08/RLX-1%20c67ec860f01241819e120e2fb97df8b6.md)

[****GLX-2**** ](Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08/GLX-2%209872a322fab644dfba2a4135e044c50f.md)

[**BLX-3** ](Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08/BLX-3%20ed3d3dc2f6e8403ab18d2583536938d6.md)

[**WLX-4** ](Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08/WLX-4%20ee56ac0c96e34d6ca005df782840cd54.md)

[**GLX-2-AS** ](Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08/GLX-2-AS%20c2bc76db73584ccfaca114f2fb2032ad.md)

[**MRS-6X** ](Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08/MRS-6X%20d05becadb7e049e1b97665fa3b72098e.md)