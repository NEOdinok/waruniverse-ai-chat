# Hangars

Owner: Artem AK

# **Hangar**

You can not only store your Ship in a Hangar hall, but you can also own additional Hangar spaces (up to a maximum of 5) to store multiple ships. 

<aside>
💡 Hangars can be switched at safe zones!

</aside>

<aside>
💡 **Warning!** The ship you buy changes with the ship in your current hangar. Don't forget to change your hangar before buying a new ship.

</aside>

# **Hangar change price: 300 PLT**

| Hangar | Price (PLT) |
| --- | --- |
| 1st | Free |
| 2nd | 25.000 PLT |
| 3rd | 100.000 PLT |
| 4th | 250.000 PLT |
| 5th | 1.000.000 PLT |