# Maps: X-5

Owner: Artem AK

# E-5

![E5.png](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc/E5.png)

**E-5** is the map of the Orion Empire.

## **Aliens**

- [Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 30x
- [Hyper Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 5x
- [Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md) - 24x
- [Hyper Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md) - 6x

## **Portals**

- Top Right: [E-6](Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb.md)
- Right Middle: [E-7](Maps%20X-7%2047d1869952274ca4b56f277bfc6f7610.md)
- Top Left: [G-1](Map%20G-1%20fb9f98f27cc144ff8b55ecbcc178722a.md)
- Bottom Left: [T-1](Map%20T-1%20d3022dc7530045b2a4f7a5f807e617d1.md)

## **Special Events**

- [Group Mission](Group%20Mission%205731b02a8b944878af747efd2603fdca.md)
- [Sector-18](Sector-18%2036c8628d052d48d88fce3337209dec1a.md)

## **Level Requirements**

Orion Empire players require to be **Level 10** to access this map. Solar Conglomerate and Vega Union players require to be **Level 13** to invade this map.

# R-5

![R5.png](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc/R5.png)

**R-5** is the map of the Solar Conglomerate.

## **Aliens**

- [Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 30x
- [Hyper Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 5x
- [Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md) - 24x
- [Hyper Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md) - 6x

## **Portals**

- Top Middle: [R-6](Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb.md)
- Top Left: [R-7](Maps%20X-7%2047d1869952274ca4b56f277bfc6f7610.md)
- Bottom Left: [G-1](Map%20G-1%20fb9f98f27cc144ff8b55ecbcc178722a.md)
- Bottom Right: [T-1](Map%20T-1%20d3022dc7530045b2a4f7a5f807e617d1.md)

## **Special Events**

- [Group Mission](Group%20Mission%205731b02a8b944878af747efd2603fdca.md)
- [Sector-18](Sector-18%2036c8628d052d48d88fce3337209dec1a.md)

## **Level Requirements**

Solar Conglomerate players require to be **Level 10** to access this map. Orion Empire and Vega Union players require to be **Level 13** to invade this map.

# U-5

![U5.png](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc/U5.png)

**U-5** is the map of the Vega Union.

## **Aliens**

- [Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 30x
- [Hyper Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 5x
- [Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md) - 24x
- [Hyper Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md) - 6x

## **Portals**

- Top Right: [T-1](Map%20T-1%20d3022dc7530045b2a4f7a5f807e617d1.md)
- Top Left: [G-1](Map%20G-1%20fb9f98f27cc144ff8b55ecbcc178722a.md)
- Bottom Left: [U-7](Maps%20X-7%2047d1869952274ca4b56f277bfc6f7610.md)
- Right Middle: [U-6](Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb.md)

## **Special Events**

- [Group Mission](Group%20Mission%205731b02a8b944878af747efd2603fdca.md)
- [Sector-18](Sector-18%2036c8628d052d48d88fce3337209dec1a.md)

## **Level Requirements**

Vega Union players require to be **Level 10** to access this map. Orion Empire and Solar Conglomerate players require to be **Level 13** to invade this map.