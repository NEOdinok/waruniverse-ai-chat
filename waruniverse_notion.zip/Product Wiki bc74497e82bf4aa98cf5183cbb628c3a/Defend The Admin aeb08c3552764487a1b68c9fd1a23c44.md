# Defend The Admin

Owner: Artem AK

![dta.png](Defend%20The%20Admin%20aeb08c3552764487a1b68c9fd1a23c44/dta.png)

Destroy enemy admins and defend yours - this is the main task.

## Rules and Basics:

- Each faction has an [admin](https://www.notion.so/Staff-team-48f83f6794a244cbbfe6fc41554b9262?pvs=21) on a [Freighter](Convoy%2016c487b4b4d44b4c9e0c4165dd0a2988.md) ship at [X-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md) map of each company.
- The goal is to destroy enemy [admins](https://www.notion.so/Staff-team-48f83f6794a244cbbfe6fc41554b9262?pvs=21) and defend your own [admin](https://www.notion.so/Staff-team-48f83f6794a244cbbfe6fc41554b9262?pvs=21).
- To win the event and get a reward, each faction must destroy the Vega, Solar, and Orion [admins](https://www.notion.so/Staff-team-48f83f6794a244cbbfe6fc41554b9262?pvs=21), and the last [admin](https://www.notion.so/Staff-team-48f83f6794a244cbbfe6fc41554b9262?pvs=21) must survive for a specific amount of time.
- If no [admin](https://www.notion.so/Staff-team-48f83f6794a244cbbfe6fc41554b9262?pvs=21) is killed in the first 15 minutes, they will move to the center [X-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md) map and stay there for another 15 minutes.
- If no admin is killed during this time or if two are left, the final fight will take place on the [T1](Map%20T-1%20d3022dc7530045b2a4f7a5f807e617d1.md) map.
- The event lasts approximately one hour.

## Important Notes:

- To prevent clan play with the admin account, you will be playing on a different faction than your main account.
- Each administrator's ship must have the same amount of HP (1,000,000,000).
- To take less damage, you should have full [DCH](Drone%20Covers%20fe91ff98efef4ee58233886feac6b57b.md).
- Five minutes before the event, the admin's ships should be in the center of the [X-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md) map to allow players to gather and defend their own administrator.
- Each [administrator](https://www.notion.so/Staff-team-48f83f6794a244cbbfe6fc41554b9262?pvs=21) should communicate with their own company using the company chat and use English only.
- [Administrators](https://www.notion.so/Staff-team-48f83f6794a244cbbfe6fc41554b9262?pvs=21) can fight enemy [ships](Shuttle%2029b2c4b5102543c8ac9a9489bccc9198.md) but should stay close to the center of the map.
- [Admins](https://www.notion.so/Staff-team-48f83f6794a244cbbfe6fc41554b9262?pvs=21) should have [Dungid](https://www.notion.so/Dungid-b9874271f1d94c498dd46e0b6efbdda9?pvs=21) and [Xureon](https://www.notion.so/Xureon-5e83a37408eb43c68024cb58dd29d5ed?pvs=21) on their ship.
- [Admins](https://www.notion.so/Staff-team-48f83f6794a244cbbfe6fc41554b9262?pvs=21) should change their nickname to SOLARxADMIN, VEGAxADMIN, or ORIONxADMIN.

## Rules for Admins:

- If you are killed, take a screenshot of the player's nickname who killed you.
- If you die, move your ship to map [X-1](Maps%20X-1%20de2a8dd8204249bcb3d4ff1442885009.md).
- Using spin in galaxy gates to gain extra HP is prohibited.
- Standing on the portals in the safe zone is not allowed.
- During the battle, the administrator may move around the entire map, but after the end of the battle, they must immediately return to the center of the map.