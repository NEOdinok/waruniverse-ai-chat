# Shield Generators

Owner: Artem AK

# ****SG-1****

![****SG-1****](Shield%20Generators%20cf10852d8ed04fb08c52d19ff2b53284/Shield1.png)

****SG-1****

| Price | 20.000 BTC |
| --- | --- |
| Shield | 5.000 |
| Absorption | 60% |

**SG-1** is the weakest shield generator in the game.

## **Obtaining**

- Generators (in Shop for 20.000 BTC)

# **SG-2**

![**SG-2**](Shield%20Generators%20cf10852d8ed04fb08c52d19ff2b53284/1Shield2.png)

**SG-2**

| Price | 350.000 BTC |
| --- | --- |
| Shield | 10.000 |
| Absorption | 70% |

**SG-2** is the another shield generator in the game.

## **Obtaining**

- Generators (in Shop for 350.000 BTC)

# **SG-3**

![**SG-3**](Shield%20Generators%20cf10852d8ed04fb08c52d19ff2b53284/Shield3.png)

**SG-3**

| Price | 20.000 PLT |
| --- | --- |
| Shield | 16.000 |
| Absorption | 85% |

**SG-3** is the elite shield generator in the game.

## **Obtaining**

- Generators (in Shop for 20.000 PLT)
- [Auction](Auction%2089a99a098f044657a6a7d6c12227b32b.md)

[SG-1](Shield%20Generators%20cf10852d8ed04fb08c52d19ff2b53284/SG-1%2038153d3eedb049db89b81c67249da763.md)

[SG-2](Shield%20Generators%20cf10852d8ed04fb08c52d19ff2b53284/SG-2%20229cabc1b22e489ba948911018076c1f.md)

[SG-3](Shield%20Generators%20cf10852d8ed04fb08c52d19ff2b53284/SG-3%2018ae552c7d2d4a8c9d4e4e6c78e3b11f.md)