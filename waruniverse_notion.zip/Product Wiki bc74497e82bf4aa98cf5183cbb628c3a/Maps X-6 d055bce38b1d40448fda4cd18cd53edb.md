# Maps: X-6

Owner: Artem AK

# E-6

![E6.png](Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb/E6.png)

**E-6** is the map of the Orion Empire.

## **Aliens**

- [Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 30x
- [Hyper Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 15x
- [Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md) - 25x
- [Hyper Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md) - 6x
- [Quattroid](Quattroid%20884f394cf89d4978b6e7ed0489219510.md) - 2x

## **Portals**

- Top Right: [E-7](Maps%20X-7%2047d1869952274ca4b56f277bfc6f7610.md)
- Bottom Left: [E-5](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md)

## **Special Events**

- [Worm Hole](Wormhole%20b62fc31319c745d2a705a9102cc9ab87.md)
- [Free Pvp Tour](Free%20PVP%20Tour%200381f34fdecd4afa88f967b0d0e62391.md)

## **Level Requirements**

Orion Empire players require to be **Level 12** to access this map. Solar Conglomerate and Vega Union players require to be **Level 15** to invade this map.

# R-6

![R6.png](Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb/R6.png)

**R-6** is the map of the Solar Conglomerate.

## **Aliens**

- [Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 30x
- [Hyper Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 15x
- [Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md) - 25x
- [Hyper Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md) - 6x
- [Quattroid](Quattroid%20884f394cf89d4978b6e7ed0489219510.md) - 2x

## **Portals**

- Top Left: [R-7](Maps%20X-7%2047d1869952274ca4b56f277bfc6f7610.md)
- Bottom Right: [R-5](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md)

## **Special Events**

- [Worm Hole](Wormhole%20b62fc31319c745d2a705a9102cc9ab87.md)
- [Free Pvp Tour](Free%20PVP%20Tour%200381f34fdecd4afa88f967b0d0e62391.md)

## **Level Requirements**

Solar Conglomerate players require to be **Level 12** to access this map. Orion Empire and Vega Union players require to be **Level 15** to invade this map.

# U-6

![U6.png](Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb/U6.png)

**U-6** is the map of the Vega Union.

## **Aliens**

- [Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 30x
- [Hyper Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 15x
- [Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md) - 25x
- [Hyper Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md) - 6x
- [Quattroid](Quattroid%20884f394cf89d4978b6e7ed0489219510.md) - 2x

## **Portals**

- Left Middle: [U-7](Maps%20X-7%2047d1869952274ca4b56f277bfc6f7610.md)
- Right Middle: [U-5](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md)

## **Special Events**

- [Worm Hole](Wormhole%20b62fc31319c745d2a705a9102cc9ab87.md)
- [Free Pvp Tour](Free%20PVP%20Tour%200381f34fdecd4afa88f967b0d0e62391.md)

## **Level Requirements**

Vega Union players require to be **Level 12** to access this map. Orion Empire and Solar Conglomerate players require to be **Level 15** to invade this map.