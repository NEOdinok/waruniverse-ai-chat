# Zeta Aggression Sector

Owner: Artem AK

![Zeta.png](Zeta%20Aggression%20Sector%208d65b804529742149aa2f7a01cd01fe4/Zeta.png)

Aliens have more enemies in Zeta Sector than we have spaceships. Prepare your ship and give a good fight to invaders!

# **Requirements**

Zeta Aggression Sector requires **48** parameters to be built.

# **Waves**

### **Wave 1**

20 [Hyper Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md)

### **Wave 2**

20 [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md)

### **Wave 3**

20 [Hyper Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md)

### **Wave 4**

10 [Ultra Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md), 6 [Ultra Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) and 3 [Ultra Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md)

### **Wave 5**

20 [Hyper Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md)

### **Wave 6**

10 [Hyper Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md)

### **Wave 7**

10 [Hyper Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md)

### **Wave 8**

6 [Ultra Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md), 4 [Ultra Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) and 1 [Ultra Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md)

### **Wave 9**

20 [Hyper Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md)

### **Wave 10**

10 [Hyper Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md)

### **Wave 11**

5 [Hyper Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md)

### **Wave 12**

4 [Ultra Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md), 2 [Ultra Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md) and 1 [Ultra Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md)

### **Wave 13**

15 [Hyper Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md)

### **Wave 14**

15 [Hyper Vortex](Vortex%201def8df83c27449e9b924343ad8224f3.md)

### **Wave 15**

3 [Ultra Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md), 3 [Ultra Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md), 3 [Ultra Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md), 2 [Ultra Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md), 1 [Ultra Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md), 1 [Ultra Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md), 1 [Ultra Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md), 1 [Ultra Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md), 1 [Ultra Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md), 1 [Ultra Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md) and 1 [Ultra Vortex](Vortex%201def8df83c27449e9b924343ad8224f3.md)

# Rewards

| Experience | 4.000.000 |
| --- | --- |
| Honor | 100.000 |
| Platinum | 25.000 |
| https://www.notion.so/WLX-4-7aca22a0c0374b07ae58b44741c35272?pvs=21 | 40.000 |