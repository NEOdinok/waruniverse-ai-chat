# In-game currency

Owner: Artem AK

BTC

PLT

Gold