# Info - clan

Owner: Artem AK

![Untitled](Info%20-%20clan%20bec87bb493f74bdebc044758fc7abf72/Untitled.png)

This window shows the main clan statistics:

- Clan
- Description
- Leader
- Score
- Ranking position
- Members
- Disband clan

## Clan

Contains the tag and name of the clan.

The tag is shown to the left of the player's nickname. It may be coloured differently depending on the diplomatic status.

Clan name basically contains a decoding of the clan tag.

### Description

At this time, the clan description feature is not available to players and administration.

### Leader

Displays the clan leader. Clan leader can accept and expel players, assign diplomatic relations with other clans.

### Score

Displays the overall rating points of the clan's players.

### Ranking position

Displays the clan's position in the overall clan ranking.

### Member

Displays the total number of players in the clan.

### Clan delete

Dissolves all members of the clan, cancels all diplomatic relations with other clans, closes the clan.