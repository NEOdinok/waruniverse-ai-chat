# How to find a clan?

Owner: Artem AK

In Clan tab, the player can search for a clan and sees the clans only of his faction. 

![Untitled](How%20to%20find%20a%20clan%20c8501782c40f4277ada25a3e1d7f2d51/Untitled.png)

Clans can be filtered by **tag**, **account**, or **date of clan creation**:
If a player clicks on a clan, he will be able to apply to it by clicking “Join a clan": 

When a player submits an application to the clan, the following message appears in this tab:

If the player's application to the clan is canceled, then he will again get into the clan search box.

The notification of cancellation of his application is not received by the clan.

If the player clicks “**Join another clan**”, then his active application to the clan will be canceled and he will return to the clan search menu again.