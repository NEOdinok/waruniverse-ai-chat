# Clan System

Owner: Artem AK

The clan unites players into one team. You can join the clan from the 8th level, the clan has a separate chat, the clan players will be highlighted in green on the mine map, their game nicknames will be a different color so that you can immediately distinguish them from other players.

When leaving the clan, no penalty is imposed on the player. He can immediately apply to the clan or create his own.

[How to create a clan?](Clan%20System%20e254e91f4bf847de9658e78a9ac7384d/How%20to%20create%20a%20clan%20d685521b1df843c5a23c0ea165f9dee4.md)

[How to find a clan?](Clan%20System%20e254e91f4bf847de9658e78a9ac7384d/How%20to%20find%20a%20clan%20c8501782c40f4277ada25a3e1d7f2d51.md)

[Info - clan](Clan%20System%20e254e91f4bf847de9658e78a9ac7384d/Info%20-%20clan%20bec87bb493f74bdebc044758fc7abf72.md)