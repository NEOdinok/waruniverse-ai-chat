# EE-1

Owner: Artem AK

# **Electric Energy EE-1**

![**Electric Energy EE-1**](Electronew.png)

**Electric Energy EE-1**

Basic component for extensions usage.

## ****Obtaining****

- Picking it up from a bonus box. (Except for X-1, X-2 and X-7 maps.)
- Spinning (in Star Missions)
- Completing a quest and receiving it as a reward.
- Ammunition (in Shop )
- Gold Market
    - Standard Supply Package
    - Combat Supply Package
    - Rush Hour Supply Package