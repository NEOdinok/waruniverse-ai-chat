# WarUniverse Creators Program

Owner: Artem AK

# **Creators Program**

Do you enjoy creating videos or streaming WarUniverse content? Learn more about our exclusive Creators Program!

The Creators Program grants an opportunity for our Influencers and Content Creators to grow their channel and audience. We provide our Creators with additional resources to create the best content ever.

# **Benefits**

Creators Program significantly boosts your popularity in the game and allows you to achieve many exclusive things to dive even more deeper into the WarUniverse community!

### **What's Included**

- Creator Discord tag in the official WarUniverse Discord server.
- Exclusive access to our Creators Discord server. There you can communicate with the WarUniverse Development team and get personal answers to your questions!
- Personal in-game supporter !sup code. Let’s count how many active players are your fans!
- Personal in-game !ezstart bonus code for your new followers: they’ll have the best conditions at the beginning!
- Exclusive information and sneak peeks of new content (pre-release).

# **Requirements for Creator**

To become a Creator, you have to comply with following requirements

### **Conditions**

- Must be 16 years of age or older.
- You have at least 5 videos about WarUniverse with more than 500 views on each.
- You have at least 500 subscribers on YouTube.
- In the last 2 months you made at least 1 video related to WarUniverse with at least 500 views on it.
- Within the last 2 months you have at least one WarUniverse related video.
- You are able to communicate in English.
- You are an active and positive member of the WarUniverse Community.
- Content on your channel does not violate or promote the violation of [WarUniverse Game Rules](https://waruniverse.space/pages/legal/game-rules.html) and [EULA.](https://waruniverse.space/pages/legal/eula.html)

*If for some reason you do not meet one of the requirements, we may consider your application on an individual basis. In addition, we cannot guarantee that your application will be accepted even if it meets the conditions listed here.*

# **How to Apply?**

Create a ticket in our [main Discord server](https://discord.com/invite/BpDcXZW). To find how to do that, please navigate to #get-support channel. Inside the created ticket, please send the completed form using the template below:

- How old are you?
- Link to your YouTube channel
- Where are you from?
- Your in-game ID and nickname?
- Why do you think that you should become a WarUniverse Creator?

*When it is done, please tag @Spaiowenta and @Wald together. We will review your application and provide all necessary information to you. We appreciate all your time and effort in making WarUniverse content and wish all the Best!*