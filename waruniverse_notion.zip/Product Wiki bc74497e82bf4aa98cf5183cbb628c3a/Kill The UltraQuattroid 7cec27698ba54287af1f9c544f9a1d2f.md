# Kill The UltraQuattroid

Owner: Artem AK

The main goal is to kill the [UltraQuattroid](Quattroid%20884f394cf89d4978b6e7ed0489219510.md), which has extra hit points, in the center of the [T1](Map%20T-1%20d3022dc7530045b2a4f7a5f807e617d1.md) map.

# **Rules and Basics**

- The [UltraQuattroid](Quattroid%20884f394cf89d4978b6e7ed0489219510.md) will have extra hit points like [Admins](https://www.notion.so/Staff-team-48f83f6794a244cbbfe6fc41554b9262?pvs=21).
- The bombardier in the middle of [T-1](Map%20T-1%20d3022dc7530045b2a4f7a5f807e617d1.md) will be disabled during the event.
- Organizers will defend the [UltraQuattroid](Quattroid%20884f394cf89d4978b6e7ed0489219510.md), restore its hit points, and try to prevent it from being killed.

# **Reward**

The [company](War%20Of%20Factions%208bce5de278f94db7a0f9667c8d01fbbc.md) that kills the [UltraQuattroid](Quattroid%20884f394cf89d4978b6e7ed0489219510.md) will receive a 300% bonus for 1 hour.