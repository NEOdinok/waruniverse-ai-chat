# Map: G-1

Owner: Artem AK

![G1.png](Map%20G-1%20fb9f98f27cc144ff8b55ecbcc178722a/G1.png)

It does not belong to any factions.

# **Aliens**

- [Ultra Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md) - 10x
- [Ultra Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 10x
- [Ultra Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 10x
- [Ultra Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 10x
- [Ultra Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 8x
- [Ultra Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md) - 10x
- [Ultra Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md) - 8x
- [Ultra Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md) - 8x
- [Ultra Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md) - 10x
- [Hyper Quattroid](Quattroid%20884f394cf89d4978b6e7ed0489219510.md) - 1x
- [Ultra Quattroid](Quattroid%20884f394cf89d4978b6e7ed0489219510.md) - 1x
- [Ultra Mortron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 8x

# **Portals**

- Middle : [T-1](Map%20T-1%20d3022dc7530045b2a4f7a5f807e617d1.md)
- Other Portals : G-1 Middle Portal

# **Special Events**

- [Spaceball](Spaceball%20Gball%2041a8d2a2fd0b40319d2820359a751c9c.md)

# **Level Requirements**

Solar Conglomerate, Orion Empire and Vega Union players require to be **Level 11** to access this map.