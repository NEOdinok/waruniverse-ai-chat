# Maps: J-XX

Owner: Artem AK

# J-VO

![Jvo.png](Maps%20J-XX%205d70b406baba46cfad632d4b75162fb7/Jvo.png)

**J-VO** is the map of [Vega Union](Vega%20Union%20d13b9dcc264748b6898b717dee85af06.md) and [Orion Empire](Orion%20Empire%20a005e9dcf0b64700bb609ba6f00e3295.md).

## **Aliens**

- [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 25x
- [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 6x
- [Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 25x
- [Hyper Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 6x
- [Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 24x
- [Hyper Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 6x
- [Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 15x
- [Hyper Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 6x
- [Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 15x
- [Hyper Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 5x

## **Portals**

- Top Right: [E-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
- Bottom Left: [U-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md)

## **Special Events**

- [Wormhole](Wormhole%20b62fc31319c745d2a705a9102cc9ab87.md)

# J-SO

![jso.png](Maps%20J-XX%205d70b406baba46cfad632d4b75162fb7/jso.png)

**J-SO** is the map of [Solar Conglomerate](Solar%20Conglomerate%2022963624016b4db9b095cdeb6303fb65.md) and [Orion Empire](Orion%20Empire%20a005e9dcf0b64700bb609ba6f00e3295.md).

## **Aliens**

- [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 25x
- [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 6x
- [Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 25x
- [Hyper Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 6x
- [Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 24x
- [Hyper Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 6x
- [Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 15x
- [Hyper Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 6x
- [Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 15x
- [Hyper Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 5x

## **Portals**

- Top Right: [E-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md)
- Bottom Left: [R-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)

## **Special Events**

- [Wormhole](Wormhole%20b62fc31319c745d2a705a9102cc9ab87.md)

# J-VS

![Jvs.png](Maps%20J-XX%205d70b406baba46cfad632d4b75162fb7/Jvs.png)

**J-VS** is the map of [Vega Union](Vega%20Union%20d13b9dcc264748b6898b717dee85af06.md) and [Solar Conglomerate](Solar%20Conglomerate%2022963624016b4db9b095cdeb6303fb65.md).

## **Aliens**

- [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 25x
- [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) - 6x
- [Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 25x
- [Hyper Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md) - 6x
- [Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 24x
- [Hyper Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md) - 6x
- [Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 15x
- [Hyper Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md) - 6x
- [Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 15x
- [Hyper Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) - 5x

## **Portals**

- Top Left: [U-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
- Bottom Right: [R-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md)

## **Special Events**

- [Wormhole](Wormhole%20b62fc31319c745d2a705a9102cc9ab87.md)

## **Level Requirements**

[Vega Union](Vega%20Union%20d13b9dcc264748b6898b717dee85af06.md) and [Solar Conglomerate](Solar%20Conglomerate%2022963624016b4db9b095cdeb6303fb65.md). players require to be **Level 6** to access this map. [Orion Empire](Orion%20Empire%20a005e9dcf0b64700bb609ba6f00e3295.md) players require to be **Level 7** to invade this map.