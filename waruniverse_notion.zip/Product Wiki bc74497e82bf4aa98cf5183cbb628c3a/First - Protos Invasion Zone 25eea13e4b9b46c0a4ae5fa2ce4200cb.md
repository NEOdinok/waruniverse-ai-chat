# First - Protos Invasion Zone

Owner: Artem AK

![Protos.png](First%20-%20Protos%20Invasion%20Zone%2025eea13e4b9b46c0a4ae5fa2ce4200cb/Protos.png)

Its the number one invasion zone on our territory! Calculate all jump parameters to active teleport. Fight with aliens and get the reward!

# ****Requirements****

Protos Invasion Zone requires **32** parameters to be built.

# ****Waves****

### **Wave 1**

40 [Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md)

### **Wave 2**

50 [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md)

### **Wave 3**

60 [Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md)

### **Wave 4**

30 [Hyper Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md), 20 [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md), and 10 [Hyper Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md)

### **Wave 5**

40 [Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md)

### **Wave 6**

20 [Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md)

### **Wave 7**

20 [Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md)

### **Wave 8**

20 [Hyper Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md), 12 [Hyper Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md), and 4 [Hyper Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md)

### **Wave 9**

40 [Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md)

### **Wave 10**

15 [Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md)

### **Wave 11**

15 [Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md)

### **Wave 12**

10 [Hyper Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md), 3 [Hyper Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md), and 2 [Hyper Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md)

### **Wave 13**

30 [Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md)

### **Wave 14**

30 [Vortex](Vortex%201def8df83c27449e9b924343ad8224f3.md)

### **Wave 15**

5 [Hyper Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md), 5 [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md), 5 [Hyper Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md), 5 [Hyper Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md), 2 [Hyper Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md), 1 [Hyper Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md), 2 [Hyper Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md), 1 [Hyper Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md), 1 [Hyper Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md), 3 [Hyper Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md) and 3 [Hyper Vortex](Vortex%201def8df83c27449e9b924343ad8224f3.md)

# Rewards

| Experience | 4.000.000 |
| --- | --- |
| Honor | 100.000 |
| Platinum | 25.000 |
| https://www.notion.so/WLX-4-7aca22a0c0374b07ae58b44741c35272?pvs=21 | 40.000 |
| Drone%20Covers%20fe91ff98efef4ee58233886feac6b57b/DCD%204511c751938e458682483f647dbe596d.md | 1 |