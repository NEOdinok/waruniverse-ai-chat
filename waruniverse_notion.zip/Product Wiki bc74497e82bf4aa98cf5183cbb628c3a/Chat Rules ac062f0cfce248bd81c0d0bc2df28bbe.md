# Chat Rules

Owner: Artem AK
Tags: Chat, Process

Last update**: 12.10.2023**

| Violation Category | Violation Description | Penalty/Duration |
| --- | --- | --- |
| § 1 - Minor Violations |  | 1 Day Ban |
|  | Using a language other than the chat room's after warning | 1 Day |
|  | All-caps writing after warning | 1 Day |
|  | Repeated messages after warning | 1 Day |
|  | Mimicking another player's name to disrupt chat or provoke the players | 1 Day |
|  | Offensive or inappropriate nicknames | 1 Day |
|  | Vulgar language | 1 Day |
|  | Being toxic after warning | 1 Day |
| § 2 - Moderate Violations |  | 7 Days Ban |
|  | Offensive provocations or insults | 7 Days |
|  | Talking about drugs or politics | 7 Days |
|  | Unauthorized advertising | 7 Days |
| § 3 - Major Violations |  | 14 Days Ban |
|  | Cheating request | 14 Days |
|  | Threats or promoting violence | 14 Days |
|  | Revealing private information | 14 Days |
|  | Discrimination (race, gender, etc.) | 14 Days |
|  | Describing sexual acts | 14 Days |
|  | Insults targeting family | 14 Days |
|  | Spreading false information | 14 Days |
| § 4 - Very Serious Violations |  | 30 to 90 Days Ban |
|  | Asking to buy accounts | 30 Days |
|  | Disrespect to staff (insults up to 90 days) | 30 to 90 Days |
|  | Exposing staff identities | 30 Days |
|  | Pretending to be game staff | 30 Days |
|  | Promoting cheats or hacks | 30 Days |
| § 5 - Account & Game Security Violations |  | 365 Days Ban |
|  | Admitting to account sharing | 365 Days |
|  | Violating account ownership rules | 365 Days |
|  | Threats against staff or game | 365 Days |
| § 6 - Account Violations |  | Permanent Ban |
|  | Account trading or selling | Permanent |
|  | Using multiple accounts to break rules | Permanent |

**Note:** In case of Account Violations, Support Admins should be informed by a CM or CA for account ban.

These rules are not definitive, the Staff Team reserves the right to apply penalties in situations not mentioned here. The durations given are the minimum durations for the mentioned violations.
The Community Admins and Support Admins have the right to increase the duration of the penalty because of a violation of § 2 or § 3 up to 30 days in total and in case of a violation of Disrespect to staff is an increase up to 180 days possible.