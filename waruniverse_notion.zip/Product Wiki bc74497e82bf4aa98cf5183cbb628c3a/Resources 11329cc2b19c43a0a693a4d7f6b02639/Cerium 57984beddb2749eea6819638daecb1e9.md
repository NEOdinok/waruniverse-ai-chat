# Cerium

Owner: Artem AK

![**Cerium**](Cerium%2057984beddb2749eea6819638daecb1e9/cerium.png)

**Cerium**

A resource that can be found on the [X-3 maps](../Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md). It is one of the components for the creation of [Darkonit](Darkonit%204a1bf398958346b3bedf87a7aa660390.md).

# **Obtaining**

- Cargo from aliens
- [X-3 Maps](../Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)

# **Sell Price**

- 1 Cerium: 10 Bitcoins

# **Upgrade**

- No bonus