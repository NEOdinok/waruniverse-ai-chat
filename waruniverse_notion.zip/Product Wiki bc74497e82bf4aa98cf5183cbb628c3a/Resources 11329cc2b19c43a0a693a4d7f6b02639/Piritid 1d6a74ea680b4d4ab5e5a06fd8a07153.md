# Piritid

Owner: Artem AK

### Piritid

![**Piritid**](Piritid%201d6a74ea680b4d4ab5e5a06fd8a07153/Untitled.png)

**Piritid**

A resource that can be found on the [X-3 maps](../Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md). It is one of the components for the creation of [Azurit](Azurit%20effb4f2375bb4682b60b666828b56fe3.md).

# **Obtaining**

- Cargo from aliens
- [X-3](../Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md) Maps

# **Sell Price**

- 1 Piritid: 15 Bitcoins

# **Upgrade**

- No bonus