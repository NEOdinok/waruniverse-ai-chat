# Star Missions - Overview

Owner: Artem AK

# **[First - Protos Invasion Zone](First%20-%20Protos%20Invasion%20Zone%2025eea13e4b9b46c0a4ae5fa2ce4200cb.md)**

Its the number one invasion zone on our territory! Calculate all jump parameters to active teleport. Fight with aliens and get the reward!

- Details of the **First Protos Invasion Zone**
    
    # **Requirements**
    
    Protos Invasion Zone requires **32** parameters to be built
    
    # **Waves**
    
    ### **Wave 1**
    
    40 Hydro
    
    ### **Wave 2**
    
    50 Jenta
    
    ### **Wave 3**
    
    60 Mali
    
    ### **Wave 4**
    
    30 Hyper Hydro, 20 Hyper Jenta, and 10 Hyper Mali
    
    ### **Wave 5**
    
    40 Plarion
    
    ### **Wave 6**
    
    20 Motron
    
    ### **Wave 7**
    
    20 Xeon
    
    ### **Wave 8**
    
    20 Hyper Plarion, 12 Hyper Motron, and 4 Hyper Xeon
    
    ### **Wave 9**
    
    40 Bangoliour
    
    ### **Wave 10**
    
    15 Zavientos
    
    ### **Wave 11**
    
    15 Magmius
    
    ### **Wave 12**
    
    10 Hyper Bangoliour, 3 Hyper Zavientos, and 2 Hyper Magmius
    
    ### **Wave 13**
    
    30 Raider
    
    ### **Wave 14**
    
    30 Vortex
    
    ### **Wave 15**
    
    5 Hyper Hydro, 5 Hyper Jenta, 5 Hyper Mali, 5 Hyper Plarion, 2 Hyper Motron, 1 Hyper Xeon, 2 Hyper Bangoliour, 1 Hyper Zavientos, 1 Hyper Magmius, 3 Hyper Raider and 3 Hyper Vortex
    
    # **Rewards**
    
    | Experience | 4.000.000 |
    | --- | --- |
    | Honor | 100.000 |
    | Platinum | 25.000 |
    | https://www.notion.so/WLX-4-3f2172b297154833bc1bfc037018362b?pvs=21 | 40.000 |
    | https://www.notion.so/DCD-b0f41384355648e9ad74d7e4e7a8bd25?pvs=21 | 1 |

# **[First - Zeta Aggression Sector](First%20-%20Zeta%20Aggression%20Sector%20f6134f37ea6946a592502ce294055fc1.md)**

Aliens have more enemies in Zeta Sector than we have spaceships. Prepare your ship and give a good fight to invaders!

- Details of the First **Zeta Aggression Sector**
    
    # **Requirements**
    
    Zeta Aggression Sector requires **48** parameters to be built
    
    # **Waves**
    
    ### **Wave 1**
    
    40 Hyper Hydro
    
    ### **Wave 2**
    
    40 Hyper Jenta
    
    ### **Wave 3**
    
    40 Hyper Mali
    
    ### **Wave 4**
    
    20 Ultra Hydro, 10 Ultra Jenta and 5 Ultra Mali
    
    ### **Wave 5**
    
    20 Hyper Motron
    
    ### **Wave 6**
    
    20 Hyper Motron
    
    ### **Wave 7**
    
    14 Hyper Xeon
    
    ### **Wave 8**
    
    10 Ultra Plarion, 6 Ultra Motron and 1 Ultra Xeon
    
    ### **Wave 9**
    
    40 Hyper Bangoliour
    
    ### **Wave 10**
    
    15 Hyper Zavientos
    
    ### **Wave 11**
    
    15 Hyper Magmius
    
    ### **Wave 12**
    
    6 Ultra Bangoliour, 2 Ultra Zavientos and 1 Ultra Magmius
    
    ### **Wave 13**
    
    30 Hyper Raider
    
    ### **Wave 14**
    
    30 Hyper Vortex
    
    ### **Wave 15**
    
    5 Ultra Hydro, 5 Ultra Jenta, 5 Ultra Mali, 3 Ultra Plarion, 2 Ultra Motron, 1 Ultra Xeon, 1 Ultra Bangoliour, 1 Ultra Zavientos, 1 Ultra Magmius, 1 Ultra Raider and 1 Ultra Vortex
    
    # **Rewards**
    
    | Experience | 8.000.000 |
    | --- | --- |
    | Honor | 200.000 |
    | Platinum | 50.000 |
    | https://www.notion.so/WLX-4-3f2172b297154833bc1bfc037018362b?pvs=21 | 80.000 |
    | https://www.notion.so/DCD-b0f41384355648e9ad74d7e4e7a8bd25?pvs=21 | 1 |

# **[First East Galactic Conflict](First%20-%20East%20Galactic%20Conflict%20ee7ed9560c9e46c0a08796134c7922f8.md)**

Our faction has a big problem on the East side of the Galaxy. Try to resolve it.

- Details of the First **East Galactic Conflict**
    
    # **Requirements**
    
    East Galactic Conflict requires **74** parameters to be built
    
    # **Waves**
    
    ### **Wave 1**
    
    40 Ultra Hydro
    
    ### **Wave 2**
    
    40 Ultra Jenta
    
    ### **Wave 3**
    
    40 Ultra Mali
    
    ### **Wave 4**
    
    40 Ultra Plarion
    
    ### **Wave 5**
    
    20 Ultra Motron
    
    ### **Wave 6**
    
    15 Ultra Xeon
    
    ### **Wave 7**
    
    15 Ultra Hydro, 10 Ultra Jenta, 5 Ultra Mali, 3 Ultra Plarion, 2 Ultra Motron and 1 Ultra Xeon
    
    ### **Wave 8**
    
    40 Ultra Bangoliour
    
    ### **Wave 9**
    
    10 Ultra Zavientos
    
    ### **Wave 10**
    
    10 Ultra Magmius
    
    ### **Wave 11**
    
    6 Ultra Bangoliour, 2 Ultra Zavientos and 1 Ultra Magmius
    
    ### **Wave 12**
    
    25 Ultra Raider
    
    ### **Wave 13**
    
    25 Ultra Vortex
    
    ### **Wave 14**
    
    5 Ultra Hydro, 5 Ultra Jenta, 5 Ultra Mali, 3 Ultra Plarion, 2 Ultra Motron, 1 Ultra Xeon, 1 Ultra Bangoliour, 1 Ultra Zavientos, 1 Ultra Magmius, 1 Ultra Raider and 1 Ultra Vortex
    
    # **Rewards**
    
    | Experience | 12.000.000 |
    | --- | --- |
    | Honor | 300.000 |
    | Platinum | 75.000 |
    | https://www.notion.so/WLX-4-3f2172b297154833bc1bfc037018362b?pvs=21 | 120.000 |
    | https://www.notion.so/DCD-b0f41384355648e9ad74d7e4e7a8bd25?pvs=21 | 1 |

# [First Kratos](First%20-%20Kratos%201c738404a146435db7cad0fe601feb11.md)

Pilot, we’re picking up a radar reading of a group of hostile alien ships approaching us. We’re going to need your help to repel their attack. Be careful, one of the objects has appeared on our radar for the first time. 

- Details of the First Kratos
    
    # ****Requirements****
    
    Kratos requires 96 parameters to be built. 
    
    # Rewards
    
    | Experience | 8.000.000 |
    | --- | --- |
    | Honor | 150.000 |
    | Platinum | 50.000 |
    | https://www.notion.so/WLX-4-3f2172b297154833bc1bfc037018362b?pvs=21 | 50.000 |
    | https://www.notion.so/DCD-b0f41384355648e9ad74d7e4e7a8bd25?pvs=21 | 1 |
    | https://www.notion.so/EE-1-8b4028be6deb422db3b1cffa91589bb2?pvs=21 | 500 |
    | https://www.notion.so/TNC-130-f3b801f5128c450d934190d4b218b30f?pvs=21 | 500 |
    
    # ****Waves****
    
    ### **Wave 1**
    
    20 [Hydro](https://www.notion.so/Hydro-43dbfb90b2264b0caf0ab9d78ab0c5b5?pvs=21)
    
    10 [Jenta](https://www.notion.so/Jenta-22698fcf218a4bdb84653276a921cf2f?pvs=21)
    
    20 [Mali](https://www.notion.so/Mali-5dee13e31bd94631b8d5cc8485930797?pvs=21)
    
    10 [Plarion](https://www.notion.so/Plarion-7e0e42542f924278bae7726ecfe074f1?pvs=21)
    
    ### **Wave 2**
    
    20 [Hydro](https://www.notion.so/Hydro-43dbfb90b2264b0caf0ab9d78ab0c5b5?pvs=21)
    
    20 [Raider](https://www.notion.so/Raider-fe989165898544938407be60fece1042?pvs=21)
    
    ### **Wave 3**
    
    10 [Plarion](https://www.notion.so/Plarion-7e0e42542f924278bae7726ecfe074f1?pvs=21)
    
    20 [Bangoliour](https://www.notion.so/Bangoliour-e9fc425ee4a84eae9bfbb7a9d4d50211?pvs=21)
    
    20 [Mali](https://www.notion.so/Mali-5dee13e31bd94631b8d5cc8485930797?pvs=21)
    
    10 [Motron](https://www.notion.so/Motron-f08a63d933584fd7aa93df19ed631b3a?pvs=21)
    
    ### **Wave 4**
    
    10 [Jenta](https://www.notion.so/Jenta-22698fcf218a4bdb84653276a921cf2f?pvs=21)
    
    10 [Bangoliour](https://www.notion.so/Bangoliour-e9fc425ee4a84eae9bfbb7a9d4d50211?pvs=21)
    
    10 [Plarion](https://www.notion.so/Plarion-7e0e42542f924278bae7726ecfe074f1?pvs=21)
    
    2 [Zavientos](https://www.notion.so/Zavientos-647c8d1a34c14ce1a0249bd0f427f726?pvs=21)
    
    ### **Wave 5**
    
    20 Hyper [Hydro](https://www.notion.so/Hydro-43dbfb90b2264b0caf0ab9d78ab0c5b5?pvs=21)
    
    20 Hyper [Jenta](https://www.notion.so/Jenta-22698fcf218a4bdb84653276a921cf2f?pvs=21)
    
    20 Hyper [Mali](https://www.notion.so/Mali-5dee13e31bd94631b8d5cc8485930797?pvs=21)
    
    20 Hyper [Plarion](https://www.notion.so/Plarion-7e0e42542f924278bae7726ecfe074f1?pvs=21)
    
    ### **Wave 6**
    
    32 [Bangoliour](https://www.notion.so/Bangoliour-e9fc425ee4a84eae9bfbb7a9d4d50211?pvs=21)
    
    4 [Zavientos](https://www.notion.so/Zavientos-647c8d1a34c14ce1a0249bd0f427f726?pvs=21)
    
    ### **Wave 7**
    
    20 [Bangoliour](https://www.notion.so/Bangoliour-e9fc425ee4a84eae9bfbb7a9d4d50211?pvs=21)
    
    20 [Hyper Bangoliour](https://www.notion.so/Bangoliour-e9fc425ee4a84eae9bfbb7a9d4d50211?pvs=21)
    
    20 [Raider](https://www.notion.so/Raider-fe989165898544938407be60fece1042?pvs=21)
    
    20 [Hyper Raider](https://www.notion.so/Raider-fe989165898544938407be60fece1042?pvs=21)
    
    ### **Wave 8**
    
    20 [Bangoliour](https://www.notion.so/Bangoliour-e9fc425ee4a84eae9bfbb7a9d4d50211?pvs=21)
    
    4 [Magmius](https://www.notion.so/Magmius-447a74b14de249b1bbad9763dd8c2371?pvs=21)
    
    ### **Wave 9**
    
    20 [Vortex](https://www.notion.so/Vortex-2b40825e31964427b609c5ae9710e07e?pvs=21)
    
    10 [Hyper Vortex](https://www.notion.so/Vortex-2b40825e31964427b609c5ae9710e07e?pvs=21)
    
    2 [Hyper Zavientos](https://www.notion.so/Zavientos-647c8d1a34c14ce1a0249bd0f427f726?pvs=21)
    
    2 [Hyper Magmius](https://www.notion.so/Magmius-447a74b14de249b1bbad9763dd8c2371?pvs=21)
    
    ### **Wave 10**
    
    2 [Tark](https://www.notion.so/Tark-61e5e80cb15e47d0a629f778a2823f86?pvs=21)
    
    1 [Hyper Tark](https://www.notion.so/Tark-61e5e80cb15e47d0a629f778a2823f86?pvs=21)
    
    1 [Ultra Tark](https://www.notion.so/Tark-61e5e80cb15e47d0a629f778a2823f86?pvs=21)
    

---

# **[Protos Invasion Zone](https://www.notion.so/Protos-Invasion-Zone-2a34b920d2794caf89d6215db271594e?pvs=21)**

Its the number one invasion zone on our territory! Calculate all jump parameters to active teleport. Fight with aliens and get the reward!

- Details of the **Protos Invasion Zone**
    
    # **Requirements**
    
    Protos Invasion Zone requires **32** parameters to be built
    
    # **Waves**
    
    ### **Wave 1**
    
    20 Hydro
    
    ### **Wave 2**
    
    25 Jenta
    
    ### **Wave 3**
    
    30 Mali
    
    ### **Wave 4**
    
    16 Hyper Hydro, 10 Hyper Jenta, and 5 Hyper Mali
    
    ### **Wave 5**
    
    20 Plarion
    
    ### **Wave 6**
    
    10 Motron
    
    ### **Wave 7**
    
    10 Xeon
    
    ### **Wave 8**
    
    10 Hyper Plarion, 6 Hyper Motron, and 2 Hyper Xeon
    
    ### **Wave 9**
    
    20 Bangoliour
    
    ### **Wave 10**
    
    10 Zavientos
    
    ### **Wave 11**
    
    5 Magmius
    
    ### **Wave 12**
    
    6 Hyper Bangoliour, 2 Hyper Zavientos, and 1 Hyper Magmius
    
    ### **Wave 13**
    
    15 Raider
    
    ### **Wave 14**
    
    15 Vortex
    
    ### **Wave 15**
    
    3 Hyper Hydro, 3 Hyper Jenta, 3 Hyper Mali, 3 Hyper Plarion, 1 Hyper Motron, 1 Hyper Xeon, 1 Hyper Bano, 1 Hyper Zavi, 1 Hyper Magm, 2 Hyper Raider, and 2 Hyper Vortex
    
    # **Rewards**
    
    | Experience | 2.000.000 |
    | --- | --- |
    | Honor | 50.000 |
    | Platinum | 12.500 |
    | https://www.notion.so/WLX-4-3f2172b297154833bc1bfc037018362b?pvs=21 | 20.000 |

# **[Zeta Aggression Sector](Zeta%20Aggression%20Sector%208d65b804529742149aa2f7a01cd01fe4.md)**

Aliens have more enemies in Zeta Sector than we have spaceships. Prepare your ship and give a good fight to invaders!

- Details of the **Zeta Aggression Sector**
    
    # **Requirements**
    
    Zeta Aggression Sector requires **48** parameters to be built
    
    # **Waves**
    
    ### **Wave 1**
    
    20 Hyper Hydro
    
    ### **Wave 2**
    
    20 Hyper Jenta
    
    ### **Wave 3**
    
    20 Hyper Mali
    
    ### **Wave 4**
    
    10 Ultra Hydro, 6 Ultra Jenta and 3 Ultra Mali
    
    ### **Wave 5**
    
    `20 Hyper Plarion`
    
    ### **Wave 6**
    
    10 Hyper Motron
    
    ### **Wave 7**
    
    10 Hyper Xeon
    
    ### **Wave 8**
    
    6 Ultra Plarion, 4 Ultra Motron and 1 Ultra Xeon
    
    ### **Wave 9**
    
    20 Hyper Bangoliour
    
    ### **Wave 10**
    
    10 Hyper Zavientos
    
    ### **Wave 11**
    
    5 Hyper Magmius
    
    ### **Wave 12**
    
    4 Ultra Bangoliour, 2 Ultra Zavientos and 1 Ultra Magmius
    
    ### **Wave 13**
    
    15 Hyper Raider
    
    ### **Wave 14**
    
    15 Hyper Vortex
    
    ### **Wave 15**
    
    3 Ultra Hydro, 3 Ultra Jenta, 3 Ultra Mali, 2 Ultra Plarion, 1 Ultra Motron, 1 Ultra Xeon, 1 Ultra Bangoliour, 1 Ultra Zavientos, 1 Ultra Magmius, 1 Ultra Raider and 1 Ultra Vortex
    
    # **Rewards**
    
    | Experience | 4.000.000 |
    | --- | --- |
    | Honor | 100.000 |
    | Platinum | 25.000 |
    | https://www.notion.so/WLX-4-3f2172b297154833bc1bfc037018362b?pvs=21 | 40.000 |

# **[East Galactic Conflict](East%20Galactic%20Conflict%20c01009b64e9542c3bfa7b23c569176df.md)**

Our faction has a big problem on the East side of the Galaxy. Try to resolve it.

- Details of the **East Galactic Conflict**
    
    # **Requirements**
    
    East Galactic Conflict requires **74** parameters to be built
    
    # **Waves**
    
    ### **Wave 1**
    
    20 Ultra Hydro
    
    ### **Wave 2**
    
    20 Ultra Jenta
    
    ### **Wave 3**
    
    20 Ultra Mali
    
    ### **Wave 4**
    
    20 Ultra Plarion
    
    ### **Wave 5**
    
    10 Ultra Motron
    
    ### **Wave 6**
    
    10 Ultra Xeon
    
    ### **Wave 7**
    
    6 Ultra Hydro, 3 Ultra Jenta, 3 Ultra Mali, 2 Ulrta Plarion, 1 Ultra Motron and 1 Ultra Xeon
    
    ### **Wave 8**
    
    20 Ultra Bangoliour
    
    ### **Wave 9**
    
    5 Ultra Zavientos
    
    ### **Wave 10**
    
    5 Ultra Magmius
    
    ### **Wave 11**
    
    2 Ultra Bangoliour, 2 Ultra Zavientos and 1 Ultra Magmius
    
    ### **Wave 12**
    
    10 Ultra Raider
    
    ### **Wave 13**
    
    15 Ultra Vortex
    
    ### **Wave 14**
    
    3 Ultra Hydro, 3 Ultra Jenta, 3 Ultra Mali, 2 Ultra Plarion, 1 Ultra Motron, 1 Ultra Xeon, 1 Ultra Bangoliour, 1 Ultra Zavientos, 1 Ultra Magmius, 1 Ultra Raider and 1 Ultra Vortex
    
    # **Rewards**
    
    | Experience | 6.000.000 |
    | --- | --- |
    | Honor | 150.000 |
    | Platinum | 37.500 |
    | https://www.notion.so/WLX-4-3f2172b297154833bc1bfc037018362b?pvs=21 | 60.000 |

# [Kratos](Kratos%208943a945543f4590b98e1e63f9321883.md)

Pilot, we’re picking up a radar reading of a group of hostile alien ships approaching us. We’re going to need your help to repel their attack. Be careful, one of the objects has appeared on our radar for the first time. 

- Details of the **Kratos**
    
    # ****Requirements****
    
    Kratos requires 96 parameters to be built. 
    
    # Rewards
    
    | Experience | 8.000.000 |
    | --- | --- |
    | Honor | 150.000 |
    | Platinum | 50.000 |
    | https://www.notion.so/WLX-4-3f2172b297154833bc1bfc037018362b?pvs=21 | 50.000 |
    | https://www.notion.so/DCD-b0f41384355648e9ad74d7e4e7a8bd25?pvs=21 | 1 |
    | https://www.notion.so/EE-1-8b4028be6deb422db3b1cffa91589bb2?pvs=21 | 500 |
    | https://www.notion.so/TNC-130-f3b801f5128c450d934190d4b218b30f?pvs=21 | 500 |
    
    # ****Waves****
    
    ### **Wave 1**
    
    20 [Hydro](https://www.notion.so/Hydro-43dbfb90b2264b0caf0ab9d78ab0c5b5?pvs=21)
    
    10 [Jenta](https://www.notion.so/Jenta-22698fcf218a4bdb84653276a921cf2f?pvs=21)
    
    20 [Mali](https://www.notion.so/Mali-5dee13e31bd94631b8d5cc8485930797?pvs=21)
    
    10 [Plarion](https://www.notion.so/Plarion-7e0e42542f924278bae7726ecfe074f1?pvs=21)
    
    ### **Wave 2**
    
    20 [Hydro](https://www.notion.so/Hydro-43dbfb90b2264b0caf0ab9d78ab0c5b5?pvs=21)
    
    20 [Raider](https://www.notion.so/Raider-fe989165898544938407be60fece1042?pvs=21)
    
    ### **Wave 3**
    
    10 [Plarion](https://www.notion.so/Plarion-7e0e42542f924278bae7726ecfe074f1?pvs=21)
    
    20 [Bangoliour](https://www.notion.so/Bangoliour-e9fc425ee4a84eae9bfbb7a9d4d50211?pvs=21)
    
    20 [Mali](https://www.notion.so/Mali-5dee13e31bd94631b8d5cc8485930797?pvs=21)
    
    10 [Motron](https://www.notion.so/Motron-f08a63d933584fd7aa93df19ed631b3a?pvs=21)
    
    ### **Wave 4**
    
    10 [Jenta](https://www.notion.so/Jenta-22698fcf218a4bdb84653276a921cf2f?pvs=21)
    
    10 [Bangoliour](https://www.notion.so/Bangoliour-e9fc425ee4a84eae9bfbb7a9d4d50211?pvs=21)
    
    10 [Plarion](https://www.notion.so/Plarion-7e0e42542f924278bae7726ecfe074f1?pvs=21)
    
    2 [Zavientos](https://www.notion.so/Zavientos-647c8d1a34c14ce1a0249bd0f427f726?pvs=21)
    
    ### **Wave 5**
    
    20 Hyper [Hydro](https://www.notion.so/Hydro-43dbfb90b2264b0caf0ab9d78ab0c5b5?pvs=21)
    
    20 Hyper [Jenta](https://www.notion.so/Jenta-22698fcf218a4bdb84653276a921cf2f?pvs=21)
    
    20 Hyper [Mali](https://www.notion.so/Mali-5dee13e31bd94631b8d5cc8485930797?pvs=21)
    
    20 Hyper [Plarion](https://www.notion.so/Plarion-7e0e42542f924278bae7726ecfe074f1?pvs=21)
    
    ### **Wave 6**
    
    32 [Bangoliour](https://www.notion.so/Bangoliour-e9fc425ee4a84eae9bfbb7a9d4d50211?pvs=21)
    
    4 [Zavientos](https://www.notion.so/Zavientos-647c8d1a34c14ce1a0249bd0f427f726?pvs=21)
    
    ### **Wave 7**
    
    20 [Bangoliour](https://www.notion.so/Bangoliour-e9fc425ee4a84eae9bfbb7a9d4d50211?pvs=21)
    
    20 [Hyper Bangoliour](https://www.notion.so/Bangoliour-e9fc425ee4a84eae9bfbb7a9d4d50211?pvs=21)
    
    20 [Raider](https://www.notion.so/Raider-fe989165898544938407be60fece1042?pvs=21)
    
    20 [Hyper Raider](https://www.notion.so/Raider-fe989165898544938407be60fece1042?pvs=21)
    
    ### **Wave 8**
    
    20 [Bangoliour](https://www.notion.so/Bangoliour-e9fc425ee4a84eae9bfbb7a9d4d50211?pvs=21)
    
    4 [Magmius](https://www.notion.so/Magmius-447a74b14de249b1bbad9763dd8c2371?pvs=21)
    
    ### **Wave 9**
    
    20 [Vortex](https://www.notion.so/Vortex-2b40825e31964427b609c5ae9710e07e?pvs=21)
    
    10 [Hyper Vortex](https://www.notion.so/Vortex-2b40825e31964427b609c5ae9710e07e?pvs=21)
    
    2 [Hyper Zavientos](https://www.notion.so/Zavientos-647c8d1a34c14ce1a0249bd0f427f726?pvs=21)
    
    2 [Hyper Magmius](https://www.notion.so/Magmius-447a74b14de249b1bbad9763dd8c2371?pvs=21)
    
    ### **Wave 10**
    
    2 [Tark](https://www.notion.so/Tark-61e5e80cb15e47d0a629f778a2823f86?pvs=21)
    
    1 [Hyper Tark](https://www.notion.so/Tark-61e5e80cb15e47d0a629f778a2823f86?pvs=21)
    
    1 [Ultra Tark](https://www.notion.so/Tark-61e5e80cb15e47d0a629f778a2823f86?pvs=21)