# Downloading & Registration

Owner: Artem AK

1. To register, you need to download the game client.
➡️ For **Windows**, **Mac**, and **Linux**, download from the [official website](https://waruniverse.space/pages/download.html),
➡️ For **Android** devices, download through [Google play](https://play.google.com/store/apps/details?id=com.spaiowenta.waruniverse),
➡️ For **iOS** devices, download through [App Store](https://apps.apple.com/app/waruniverse/id1441907755?platform=iphone).
➡️ For Huawei and other devices, you need to download the .APK file from the [official website](https://waruniverse.space/pages/download.html).
2. Launch the game.
➡️ The main screen with the [EULA](https://waruniverse.space/pages/legal/eula.html) agreement window opens.
➡️ Move the toggle to "Accept".
➡️ Click "Continue".
➡️ After that, we will be taken to the main screen.
3. Click "Create new".
4. Enter your desired **username** and **password**.
➡️ The username can only contain English letters and numbers.
➡️ The maximum length of the username is 32 characters.
➡️ The maximum length of the password is 32 characters.
➡️ The username is unique.
➡️ The username does not change when the nickname is changed.
➡️ The username will be the first nickname in the game.
5. After entering the details, click the "Play" button.
6. We are taken back to the main screen with saved **username** and **password**.
7. Language selection.
➡️ Click the icon at the bottom left.
➡️ Clicking the icon will open a list with a choice of several languages.
➡️ To select the client language, click it once.
➡️ After selecting the language, click the "OK" button.
➡️ After clicking "OK", we will be returned to the main screen.
8. Server selection.
➡️ To select a server, click the icon at the bottom left.
➡️ Clicking the icon will open a list with a choice of several servers.
➡️ To select a server, click it once.
➡️ After selecting the server, click "OK".
➡️ After clicking "OK", we will be returned to the main screen.
9. Automatic login.
➡️ With automatic login enabled, logging into the game account will be done automatically when launching the game client, including if the player was "kicked out" of the game.
➡️ With automatic login disabled, logging into the game account will only be done after selecting the account from the list that you want to log in to.