# Vega Union

Owner: Artem AK

![****Vega Union's Commander****](Vega%20Union%20d13b9dcc264748b6898b717dee85af06/Char_vega.png)

****Vega Union's Commander****

Vega Union is a formidable force within the universe, and players can choose to align themselves with this powerful faction in the game WarUniverse. This faction is known for its conflict with two other factions, the Orion Empire and the Solar Conglomerate, and players can expect to engage in battles against these two opposing forces. Despite its reputation as an enemy faction, Vega Union has a complex political structure with various sub-factions vying for power. There are rumors of a rogue faction within Vega Union that seeks to overthrow the current leadership and establish a new order. As players progress through the game, they may uncover more about the internal politics of Vega Union and the motives behind their conflict with the Orion Empire and Solar Conglomerate.

# **Maps**

### **Lower Maps**

- [U-1](Maps%20X-1%20de2a8dd8204249bcb3d4ff1442885009.md) (Base)
- [U-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md)
- [U-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
- [J-VS](Maps%20J-XX%205d70b406baba46cfad632d4b75162fb7.md)
- [J-VO](Maps%20J-XX%205d70b406baba46cfad632d4b75162fb7.md)

### **Upper Maps**

- [U-5](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md)
- [U-6](Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb.md)
- [U-7](Maps%20X-7%2047d1869952274ca4b56f277bfc6f7610.md) (Base)