# Social media

Owner: Artem AK

# Instagram

[](https://www.instagram.com/waruniversegame/)

# Website

[WarUniverse](https://waruniverse.space)

# Facebook

[WarUniverse](https://www.facebook.com/waruniverse)

# TikTok

[WarUniverse's Creator Profile](https://www.tiktok.com/@waruniverse)

# VKontakte

[WarUniverse - Война за вселенную - MMORPG](https://vk.com/waruniverse)

# YouTube

[WarUniverse Game](https://www.youtube.com/channel/UCghbjKNxDZVMRGxRmcFCVsQ)

# Discord

[Join the WarUniverse Discord Server!](https://discord.com/invite/BpDcXZW)