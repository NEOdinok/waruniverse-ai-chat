# How to create a clan?

Owner: Artem AK

Any player can create a clan from 8 LVL. The cost of creating a clan is 300,000 Bitcoins.

The tag and the name of the clan can only be entered in Latin letters. The clan tag can contain only 4 characters, and the name can contain up to 50 characters.

A change to special characters is also available, for this the player needs to contact the support service by sending the following message:

> Server:
Clan leader id:
New clan tag:
> 

Characters that can be used in the clan tag:

```jsx
ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789
!`?'.,;:()[]{}<>|/@^$€-%+=#_&~*АБВГДЕЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ
абвгдеежзийклмнопрстуфхцчшщъыьэюя•†áčďéěíňóřšťúůýžÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ
ąćęłńóśźżĄĆĘŁŃÓŚŹŻàâæçéèêëïîôœùûüÿÀÂÆÇÉÈÊËÏÎÔŒäöüßÄÖÜẞâçğıİîöşüû
ÂÇĞIİÎÖŞÜÛàèéìòóùÀÈÉÌÒÓÙáéíñóúü¿¡ÁÉÍÑÓÚÜ
```

When a player has managed to create a clan, he will be immediately transferred to the main page of the clan:

When the player failed to create a clan, he will receive the following message:

The player has not reached level 8

The balance of bitcoins is less than 300,000

A clan with this tag or name already exists