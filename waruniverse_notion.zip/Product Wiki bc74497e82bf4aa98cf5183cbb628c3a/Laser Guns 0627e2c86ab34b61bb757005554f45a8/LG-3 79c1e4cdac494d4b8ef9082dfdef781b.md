# LG-3

Owner: Artem AK

![**LG-3**](Gun2.png)

**LG-3**

| Price | 20.000 PLT |
| --- | --- |
| Damage | 150 |

**LG-3** is a strong laser gun in the game, dealing up to 150 damage per shot.

## **Obtaining**

- Guns (in Shop for 20.000 PLT)
- Auction