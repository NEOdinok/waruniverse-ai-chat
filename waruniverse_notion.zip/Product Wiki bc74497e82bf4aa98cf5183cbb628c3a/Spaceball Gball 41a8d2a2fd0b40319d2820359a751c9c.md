# Spaceball/Gball

Owner: Artem AK

![Spaceball.png](Spaceball%20Gball%2041a8d2a2fd0b40319d2820359a751c9c/Spaceball.png)

Spaceball is a regular event happening at Weekends and every Wednesday. During Spaceball players from each [faction](War%20Of%20Factions%208bce5de278f94db7a0f9667c8d01fbbc.md) participating have to score as many points as possible by guiding the “ball” through shooting it to the portals of their faction. One hour after winning the Spaceball faction that scored most points will be earning significantly higher rewards from destroying aliens.

**Spaceball bonus does not apply to the aliens inside Star Missions.**

# **T-1 Spaceball**

During the Spaceball on [T-1](Map%20T-1%20d3022dc7530045b2a4f7a5f807e617d1.md) you are fighting over control of 1 ball with enemy factions. Bonus goes to the winners.

# **G-1 Spaceball (GBall)**

When G-1 Spaceball starts there are activated special respawn points for each [faction](War%20Of%20Factions%208bce5de278f94db7a0f9667c8d01fbbc.md) and close to them spawns a ball, one for each faction. From that point on you have to score as many points as possible while obstructing other factions from scoring points faster than you do. Bonus goes to the winners.

# **Rewards**

300%(PLT, BTC, EXP, HNR) bonus for 1 hour for the winning [faction](War%20Of%20Factions%208bce5de278f94db7a0f9667c8d01fbbc.md).