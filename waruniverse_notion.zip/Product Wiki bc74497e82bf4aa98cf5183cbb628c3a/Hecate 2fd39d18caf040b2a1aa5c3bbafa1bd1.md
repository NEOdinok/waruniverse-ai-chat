# Hecate

Owner: Artem AK

![**Hecate**](Hecate%202fd39d18caf040b2a1aa5c3bbafa1bd1/Hecate.png)

**Hecate**

The **Hecate**-Ship has the second highest life points in the WarUniverse. An additional feature of this ship is that despite its high life points, it is not vulnerable to [nuclear bombs](Extensions%20ad99098f7be6439b877727e8069749b1.md), as the passive ability reduces the damage by 80%. With its very good survivability and decent armament, it is ideal for levelling up and completing quests on any map of your own faction. It is one of the slowest ships in WarUniverse, 

****Ship abilities****

- 80 % damage reduction against damage dealt by [nuclear bombs](Extensions%20ad99098f7be6439b877727e8069749b1.md)

| Price | 2.500.000 BTC |
| --- | --- |
| Hitpoints | 512.000 |
| Speed | 300 |
| Laser%20Guns%200627e2c86ab34b61bb757005554f45a8.md | 12 |
| Shield%20Generators%20cf10852d8ed04fb08c52d19ff2b53284.md | 12 |
| Extensions%20ad99098f7be6439b877727e8069749b1.md | 4 |
| Cargo | 3000 |