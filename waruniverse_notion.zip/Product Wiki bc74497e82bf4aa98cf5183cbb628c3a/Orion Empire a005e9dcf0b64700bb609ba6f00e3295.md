# Orion Empire

Owner: Artem AK

![****Orion Empire's Commander****](Orion%20Empire%20a005e9dcf0b64700bb609ba6f00e3295/Char_orion.png)

****Orion Empire's Commander****

The Orion Empire, a powerful and menacing force in the WarUniverse, is one of the three main factions that players can choose from. Known for their advanced technology and ruthless tactics, they are the sworn enemy of the Solar Conglomerate and the Vega Union, two other factions that players can align themselves with. The Orion Empire is a formidable foe, but also a potentially rewarding ally for those who are willing to take the risk of joining forces with them. Additionally, their long-standing rivalry with the Solar Conglomerate and the Vega Union adds an exciting layer of depth to the gameplay experience, as players must navigate the complex web of alliances and tensions between the three factions in order to succeed in the WarUniverse.

# **Maps**

### **Lower Maps**

- [E-1](Maps%20X-1%20de2a8dd8204249bcb3d4ff1442885009.md) (Base)
- [E-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md)
- [E-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
- [J-SO](Maps%20J-XX%205d70b406baba46cfad632d4b75162fb7.md)
- [J-VO](Maps%20J-XX%205d70b406baba46cfad632d4b75162fb7.md)

### **Upper Maps**

- [E-5](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md)
- [E-6](Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb.md)
- [E-7](Maps%20X-7%2047d1869952274ca4b56f277bfc6f7610.md) (Base)