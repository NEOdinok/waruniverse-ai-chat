# Zephyrus

Owner: Artem AK

![**Zephyrus**](Zephyrus%2053c9a93003fc43ac8a9e4a9c5dbcdc8c/Zephyrus.png)

**Zephyrus**

The **Zephyrus**-Ship is suitable for new players when leveling up and completing tasks on lower maps  [X-1](Maps%20X-1%20de2a8dd8204249bcb3d4ff1442885009.md), [X-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md), [X-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md).

| Price | 90.000 BTC |
| --- | --- |
| Hitpoints | 76.000 |
| Speed | 380 |
| Laser%20Guns%200627e2c86ab34b61bb757005554f45a8.md | 4 |
| Shield%20Generators%20cf10852d8ed04fb08c52d19ff2b53284.md | 3 |
| Extensions%20ad99098f7be6439b877727e8069749b1.md | 3 |
| Cargo | 300 |