# Support

Owner: Artem AK

<aside>
💡 WarUniverse Support Admins Team are available on waruniversehelp@gmail.com!

</aside>

# **ACCOUNT QUESTIONS**

## **Payment problem:**

If you have a problem with your payment, send an email to [waruniversehelp@gmail.com](mailto:waruniversehelp@gmail.com) with the subject "Payment problem" and include the following information:

```
Server:
Account ID/Login:
Short explanation of your problem:

```

<aside>
💡 **IMPORTANT NOTE:** Without a receipt or a screenshot of your purchase history, we won't be able to help you properly. The receipt must include the date of purchase, the name of the bundle, the price, and the transaction number.

</aside>

:pushpin: Please note that we do not accept bank statements or SMS alerts about money withdrawals.

## **Account recovery:**

If you need help recovering your account, send an email to [waruniversehelp@gmail.com](mailto:waruniversehelp@gmail.com) with the subject "Account recovery" and include the following information:

```
Attach receipts if you made any payments (important):
Server:
Login name:
Nickname:
ID:
Type of ships:
Approximate Last Login Date:
Approximate Account Creation Date:

```

If you're unable to provide certain information, you should leave that section blank.

## **Ship recovery:**

:question: If you lost your H-J or H-G ship, send an email to [waruniversehelp@gmail.com](mailto:waruniversehelp@gmail.com) with the subject "Ship recovery" and include the following information:

```
Account ID/Login:
Server:
Which ship was lost:
Explain how it happened:

```

## **Losses in BTC/PLT/auction:**

If you've experienced losses in BTC/PLT/auction, send an email to [waruniversehelp@gmail.com](mailto:waruniversehelp@gmail.com) with the subject "Losses" and include the following information:

```
Account ID/Login:
Server:
Date and time of the issue:
Description of the accident with enough details:

```

## **For other problems:**

If you have a different issue, send an email to [waruniversehelp@gmail.com](mailto:waruniversehelp@gmail.com) with the subject of your issue and provide as much detail as possible.

[https://forms.gle/zh7C6DRFohfJ5AzMA](https://forms.gle/zh7C6DRFohfJ5AzMA)