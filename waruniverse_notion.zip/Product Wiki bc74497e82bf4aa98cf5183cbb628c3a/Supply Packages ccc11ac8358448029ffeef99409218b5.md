# Supply Packages

Owner: Artem AK

Supply gives you a powerful set of resources, ammunition and premium status. 

When you refine your guns and rockets by the Dungid compound you are making them more stronger. 

Xureon gives more strength to your shield and speed generators.

Resources will be added to the ship on **active hangar** at the moment of purchase.

# Standard Supply Package

![**Standard Supply Package**](Supply%20Packages%20ccc11ac8358448029ffeef99409218b5/ssp.jpg)

**Standard Supply Package**

**Price: 749 Gold**

Standard Supply Package of battle provision that makes your ship more powerful. 

## Includes:

- 500 **[Dungid Compound](https://www.notion.so/Resources-c8f33e976ffa4e8eac811affd16bde5f?pvs=21)**
- 250 **[Xureon Compound](https://www.notion.so/Resources-c8f33e976ffa4e8eac811affd16bde5f?pvs=21)**
- 1.000 **Electric Energy EE-1**
- 50 **Nuclear Energy EN-702**
- 50 **Gravity Energy EG-88-3**
- 50 **Magnetic Energy EM-AP-4**
- 1 day of **Premium**

# Combat Supply Package

![**Combat Supply Package** ](Supply%20Packages%20ccc11ac8358448029ffeef99409218b5/csp.jpg)

**Combat Supply Package** 

**Price: 849 Gold**

Extended Package of battle provision that makes your ship more powerful.

## Includes:

- 1.000 **[Dungid Compound](https://www.notion.so/Resources-c8f33e976ffa4e8eac811affd16bde5f?pvs=21)**
- 500 **[Xureon Compound](https://www.notion.so/Resources-c8f33e976ffa4e8eac811affd16bde5f?pvs=21)**
- 2.000 **Electric Energy EE-1**
- 10.000 **WLX-4 Ammo**
- 5.000 **MRS-6x Ammo**
- 1 day of **Premium**

# Rush Hour Supply Package

![**Rush Hour Supply Package**](Supply%20Packages%20ccc11ac8358448029ffeef99409218b5/rhsp.jpg)

**Rush Hour Supply Package**

**Price: 949 Gold**

Biggest Package of battle provision that makes your ship more powerful.

## Includes:

- 2.000 **[Dungid Compound](https://www.notion.so/Resources-c8f33e976ffa4e8eac811affd16bde5f?pvs=21)**
- 1.000 **[Xureon Compound](https://www.notion.so/Resources-c8f33e976ffa4e8eac811affd16bde5f?pvs=21)**
- 30.000 **WLX-4 Ammo**
- 20.000 **GLX-2 AS Ammo**
- 10.000 **MRS-6x Ammo**
- 2.000 **Electric Energy EE-1**
- 1 day of **Premium**