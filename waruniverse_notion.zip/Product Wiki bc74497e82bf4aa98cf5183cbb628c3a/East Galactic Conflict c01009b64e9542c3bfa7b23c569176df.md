# East Galactic Conflict

Owner: Artem AK

![East.png](East%20Galactic%20Conflict%20c01009b64e9542c3bfa7b23c569176df/East.png)

Our faction has a big problem on the East side of the Galaxy. Try to resolve it.

# **Requirements**

East Galactic Conflict requires **74** parameters to be built

# **Waves**

### **Wave 1**

20 [Ultra Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md)

### **Wave 2**

20 [Ultra Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md)

### **Wave 3**

20 [Ultra Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md)

### **Wave 4**

20 [Ultra Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md)

### **Wave 5**

10 [Ultra Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md)

### **Wave 6**

10 [Ultra Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md)

### **Wave 7**

6 [Ultra Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md), 3 [Ultra Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md), 3 [Ultra Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md), 2 [Ultra Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md), 1 [Ultra Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md) and 1 [Ultra Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md)

### **Wave 8**

20 [Ultra Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md)

### **Wave 9**

5 [Ultra Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md)

### **Wave 10**

5 [Ultra Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md)

### **Wave 11**

2 [Ultra Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md), 2 [Ultra Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md) and 1 [Ultra Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md)

### **Wave 12**

10 [Ultra Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md)

### **Wave 13**

15 [Ultra Vortex](Vortex%201def8df83c27449e9b924343ad8224f3.md)

### **Wave 14**

3 [Ultra Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md), 3 [Ultra Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md), 3 [Ultra Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md), 2 [Ultra Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md), 1 [Ultra Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md), 1 [Ultra Xeon](Xeon%20517020bc917b45edb9d6ba66f1e6c4fa.md), 1 [Ultra Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md), 1 [Ultra Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md), 1 [Ultra Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md), 1 [Ultra Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md) and 1 [Ultra Vortex](Vortex%201def8df83c27449e9b924343ad8224f3.md)

# Rewards

| Experience | 6.000.000 |
| --- | --- |
| Honor | 150.000 |
| Platinum | 37.500 |
| https://www.notion.so/WLX-4-7aca22a0c0374b07ae58b44741c35272?pvs=21 | 60.000 |