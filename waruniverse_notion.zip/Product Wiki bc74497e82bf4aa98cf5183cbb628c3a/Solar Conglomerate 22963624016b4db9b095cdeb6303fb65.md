# Solar Conglomerate

Owner: Artem AK

![****Solar Conglomerate's Commander****](Solar%20Conglomerate%2022963624016b4db9b095cdeb6303fb65/Char_solar.png)

****Solar Conglomerate's Commander****

The Solar Conglomerate is a powerful and influential faction in the world of WarUniverse. With its advanced technology and superior military prowess, it has become a major player in the ongoing conflict between the three factions. In fact, the Solar Conglomerate is considered to be the primary enemy of both the Orion Empire and the Vega Union, two other powerful factions vying for control of the galaxy. However, despite its formidable reputation, the Solar Conglomerate has faced many challenges in its quest for dominance, including internal conflicts and external threats from rivals and enemies alike. Despite these obstacles, the Solar Conglomerate remains a force to be reckoned with, and its leaders are determined to do whatever it takes to emerge victorious in the ongoing war for control of the Galaxy.

# **Maps**

### **Lower Maps**

- [R-1](Maps%20X-1%20de2a8dd8204249bcb3d4ff1442885009.md) (Base)
- [R-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md)
- [R-3](Maps%20X-3%20eed8d514e2674c79a5e8fa7f529c661f.md)
- [J-SO](Maps%20J-XX%205d70b406baba46cfad632d4b75162fb7.md)
- [J-VS](Maps%20J-XX%205d70b406baba46cfad632d4b75162fb7.md)

### **Upper Maps**

- [R-5](Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md)
- [R-6](Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb.md)
- [R-7](Maps%20X-7%2047d1869952274ca4b56f277bfc6f7610.md) (Base)