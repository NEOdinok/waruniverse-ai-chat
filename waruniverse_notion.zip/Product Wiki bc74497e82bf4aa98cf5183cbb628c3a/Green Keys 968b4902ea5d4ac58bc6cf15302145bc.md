# Green Keys

Owner: Tizian Fl

Green keys are required to open [Green Boxes](Boxes%2093ebc4bf4cc54122b18f3099e005047b/Green%20Boxes%206bf7f2c506da40b5bca5c862a1327cfc.md) on the space map. [Green Boxes](Boxes%2093ebc4bf4cc54122b18f3099e005047b/Green%20Boxes%206bf7f2c506da40b5bca5c862a1327cfc.md) may contain a special reward, such as the [LG-4 Laser Gun](Laser%20Guns%200627e2c86ab34b61bb757005554f45a8/LG-4%20222acfcdc0834fa7b4c32a317a9f79e6.md). 

## **Obtaining**

- Keys (in Shop for 2.000 PLT)
- [Auction](Auction%2089a99a098f044657a6a7d6c12227b32b.md)