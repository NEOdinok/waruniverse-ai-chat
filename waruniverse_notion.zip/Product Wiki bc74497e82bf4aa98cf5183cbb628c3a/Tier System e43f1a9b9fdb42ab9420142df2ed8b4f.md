# Tier System

Owner: Artem AK

# **Tier System (Still under development)**

Every [laser gun](https://www.notion.so/Laser-Guns-24122993cb6b490489a7ef43af052f45?pvs=21), [shield](Shield%20Generators%20cf10852d8ed04fb08c52d19ff2b53284.md), ship, [map](Levels%20and%20Map%20Access%20c5d9f5f99cb34f20ab786e40b1311e9f.md), [resources](Resources%2011329cc2b19c43a0a693a4d7f6b02639.md) has its own level. In order to get certain items in the game, you will need to level up first.

- **Tier 1**
    
    ![Screenshot 2023-05-04 at 16.25.56.png](Tier%20System%20e43f1a9b9fdb42ab9420142df2ed8b4f/Screenshot_2023-05-04_at_16.25.56.png)
    
- **Tier 2**
    
    ![Screenshot 2023-05-04 at 16.32.32.png](Tier%20System%20e43f1a9b9fdb42ab9420142df2ed8b4f/Screenshot_2023-05-04_at_16.32.32.png)
    
- **Tier 3**
    
    ![Screenshot 2023-05-04 at 16.38.34.png](Tier%20System%20e43f1a9b9fdb42ab9420142df2ed8b4f/Screenshot_2023-05-04_at_16.38.34.png)
    

# Tier System for Gold Market

- **Gold Market. Tier 1**
    
    ![Screenshot 2023-05-04 at 16.45.58.png](Tier%20System%20e43f1a9b9fdb42ab9420142df2ed8b4f/Screenshot_2023-05-04_at_16.45.58.png)
    
- **Gold Market. Tier 2**
    
    ![Screenshot 2023-05-04 at 16.49.33.png](Tier%20System%20e43f1a9b9fdb42ab9420142df2ed8b4f/Screenshot_2023-05-04_at_16.49.33.png)
    
- **Gold Market. Tier 3**
    
    ![Screenshot 2023-05-04 at 16.52.49.png](Tier%20System%20e43f1a9b9fdb42ab9420142df2ed8b4f/Screenshot_2023-05-04_at_16.52.49.png)