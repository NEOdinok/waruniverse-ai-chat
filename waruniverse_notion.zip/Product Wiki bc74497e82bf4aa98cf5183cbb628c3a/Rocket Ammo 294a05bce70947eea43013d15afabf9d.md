# Rocket Ammo

Owner: Artem AK

# **KEP-410**

![****KEP-410****](Rocket%20Ammo%20294a05bce70947eea43013d15afabf9d/11rammo1.png)

****KEP-410****

KEP-410 is the first rocket you'll ever use, it’s damage is low.

## ****Obtaining****

• Ammunition (in Shop)

## Statistics

| Damage | 1000 |
| --- | --- |
| Range  | 600 |
| Speed | 1000 |

# **NC-30**

![**NC-30**](Rocket%20Ammo%20294a05bce70947eea43013d15afabf9d/11rammo2.png)

**NC-30**

NC-30 is the second rocket that you'll use constantly. It has a higher accuracy and damage than KEP-410.

## ****Obtaining****

- Ammunition (in Shop )
- Completing a quest and receiving it as a reward.

## Statistics

| Damage | 2000 |
| --- | --- |
| Range  | 700 |
| Speed | 1000 |

# **TNC-130**

![**TNC-130**](Rocket%20Ammo%20294a05bce70947eea43013d15afabf9d/11rammo3.png)

**TNC-130**

TNC-130 is an elite rocket that has a deals a lot of damage.

## ****Obtaining****

- Ammunition (in Shop )
- Completing a quest and receiving it as a reward.
- Spinning (in [Star Missions](https://www.notion.so/Star-Missions-Overview-9cd4528c705c467d8df770096c2b4cc4?pvs=21))

## Statistics

| Damage | 4000 |
| --- | --- |
| Range  | 800 |
| Speed | 1000 |

[**KEP-410** ](Rocket%20Ammo%20294a05bce70947eea43013d15afabf9d/KEP-410%20cba017f7c6f64dda8dbdd95ce179309c.md)

[**NC-30** ](Rocket%20Ammo%20294a05bce70947eea43013d15afabf9d/NC-30%20535948c40fdc4a5a9e1d3cc22b501f35.md)

[**TNC-130**](Rocket%20Ammo%20294a05bce70947eea43013d15afabf9d/TNC-130%20c1428b283d6846a5827b920c08cc6d19.md)