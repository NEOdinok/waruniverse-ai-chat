# Bangoliour

Owner: Artem AK

![**Bangoliour**](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb/Bangoliour.png)

**Bangoliour**

> Terrible, disgusting and very, very agile creatures that can smell your fear and your presence at a distance that Calypso travels for an impressive period of time
> 

 – these were the words one experienced hunter and traveler described these aliens. 

Bangoliour is the highest development of [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md) and [Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md). High speed allows them to reach the victim faster than you have time to blink. Even faster, Bangoliour deals with the victim. They also know how to unite in small flocks and leave the victim without a single chance of survival. It is worth noting that the armor of these creatures is very light and fragile, so if you arm yourself with good ammunition, you will be able to successfully hunt. Still, the Universe knows how to keep a balance in everything.

# **Stats**

|  | HP | Shield | Speed | Damage |
| --- | --- | --- | --- | --- |
| Bangoliour | 48000 | 33600 | 290 | 1000 |
| Hyper Bangoliour | 96000 | 67200 | 290 | 2000 |
| Ultra Bangoliour | 192000 | 134400 | 290 | 4000 |

# **Rewards**

|  | Btc | Plt | Exp | Hnr |
| --- | --- | --- | --- | --- |
| Bangoliour | 14200 | 48 | 6592 | 24 |
| Hyper Bangoliour | 28400 | 96 | 13184 | 48 |
| Ultra Bangoliour | 56800 | 192 | 26368 | 96 |

# **Locations**

|  | Location |
| --- | --- |
| Bangoliour | Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md, Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb.md, Protos%20Invasion%20Zone%2038454391f65241359fa053794e545b72.md, Sector-18%2036c8628d052d48d88fce3337209dec1a.md |
| Hyper Bangoliour | Maps%20X-5%20592f5bcda35f40cab1483da0e1b18abc.md, Maps%20X-6%20d055bce38b1d40448fda4cd18cd53edb.md, Protos%20Invasion%20Zone%2038454391f65241359fa053794e545b72.md, First%20-%20Zeta%20Aggression%20Sector%20f6134f37ea6946a592502ce294055fc1.md, Sector-18%2036c8628d052d48d88fce3337209dec1a.md |
| Ultra Bangoliour | Map%20G-1%20fb9f98f27cc144ff8b55ecbcc178722a.md, First%20-%20Zeta%20Aggression%20Sector%20f6134f37ea6946a592502ce294055fc1.md, East%20Galactic%20Conflict%20c01009b64e9542c3bfa7b23c569176df.md, Sector-18%2036c8628d052d48d88fce3337209dec1a.md |

# **Cargo Drop**

|  | Bangoliour | Hyper Bangoliour | Ultra Bangoliour |
| --- | --- | --- | --- |
| https://www.notion.so/Cerium-94559fad6493492cacc59395cad058e8?pvs=21 | 100 | 200 | 400 |
| https://www.notion.so/Mercury-df3566ab61364070898b231e8f633a67?pvs=21 | 80 | 160 | 320 |
| https://www.notion.so/Erbium-bf095bb0b73d4d399f4a8be80da35c83?pvs=21 | 80 | 160 | 320 |
| https://www.notion.so/Piritid-88e209214cb4493eb5c9e89809df20a8?pvs=21 | 100 | 200 | 400 |
| https://www.notion.so/Darkonit-54777744f17e4c6988ce4c47a3d8c6c8?pvs=21 | 8 | 16 | 32 |
| https://www.notion.so/Uranit-693c32d2b9204247ae5142c3621ddb16?pvs=21 | 24 | 48 | 96 |
| https://www.notion.so/Azurit-bce20a043ea04ec8adc9fe7e9349d053?pvs=21 | 8 | 16 | 32 |
| https://www.notion.so/Dungid-b9874271f1d94c498dd46e0b6efbdda9?pvs=21 | 2 | 4 | 8 |
| https://www.notion.so/Xureon-5e83a37408eb43c68024cb58dd29d5ed?pvs=21 | 2 | 4 | 8 |