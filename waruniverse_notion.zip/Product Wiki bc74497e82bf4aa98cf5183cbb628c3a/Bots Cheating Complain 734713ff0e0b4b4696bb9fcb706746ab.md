# Bots / Cheating Complain

Owner: Artem AK
Tags: Process

[https://forms.gle/zh7C6DRFohfJ5AzMA](https://forms.gle/zh7C6DRFohfJ5AzMA)