# Checkout

Owner: Artem AK

![**Checkout**](Checkout%20ab26166aec554117b5ef3d2afd23fabd/Checkoutnew1.png)

**Checkout**

During Checkout you will be able to take control of the 7 nodes appearing on [T-1 map](https://waruniverse.fandom.com/wiki/T-1). Each node periodically releases a certain number of [bonus boxes](Boxes%2093ebc4bf4cc54122b18f3099e005047b.md) around it and a much larger number once every few releases. Nodes start as neutral and can be taken control of by any faction, after node is captured only pilots from the faction controlling it will be able to collect bonus boxes around it. Each node after being captured has a large health pool which will decrease with time significantly making it easy to recapture after some time.