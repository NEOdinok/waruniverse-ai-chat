# Speed Generators

Owner: Artem AK

# **ACC-1**

![**ACC-1**](Speed%20Generators%20854e75ac1faa480284f7855de6261025/Speed1.png)

**ACC-1**

| Price | 80.000 BTC |
| --- | --- |
| Speed | 4 |

**ACC-1** is the weakest speed generator in the game.

## **Obtaining**

- Generators (in Shop for 80.000 BTC)

# **ACC-2**

![**ACC-2**](Speed%20Generators%20854e75ac1faa480284f7855de6261025/1Speed2.png)

**ACC-2**

| Price | 250.000 BTC |
| --- | --- |
| Speed | 7 |

**ACC-2** is the another speed generator in the game.

## **Obtaining**

- Generators (in Shop for 250.000 BTC)

# **ACC-3**

![**ACC-3**](Speed%20Generators%20854e75ac1faa480284f7855de6261025/Speed3.png)

**ACC-3**

| Price | 10.000 PLT |
| --- | --- |
| Speed | 10 |

**ACC-3** is the elite speed generator in the game.

## **Obtaining**

- Generators (in Shop for 10.000 PLT)
- [Auction](Auction%2089a99a098f044657a6a7d6c12227b32b.md)

[**ACC-1**](Speed%20Generators%20854e75ac1faa480284f7855de6261025/ACC-1%204d00dc0eac624ceebc9d1652f47f1a40.md)

[ACC-2](Speed%20Generators%20854e75ac1faa480284f7855de6261025/ACC-2%208106d0a5d2c84a43847340c73bd6caf1.md)

[ACC-3](Speed%20Generators%20854e75ac1faa480284f7855de6261025/ACC-3%20df796c838e8a405696ea2302221143e1.md)