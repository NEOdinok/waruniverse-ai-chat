# First - Kratos

Owner: Tizian Fl

![Kratos.png](First%20-%20Kratos%201c738404a146435db7cad0fe601feb11/Kratos.png)

Pilot, we’re picking up a radar reading of a group of hostile alien ships approaching us. We’re going to need your help to repel their attack. Be careful, one of the objects has appeared on our radar for the first time. 

# ****Requirements****

Kratos requires 96 parameters to be built. 

# Rewards

| Experience | 8.000.000 |
| --- | --- |
| Honor | 150.000 |
| Platinum | 50.000 |
| Laser%20Ammo%2025cdabd34a554b5db32b732a0eee9e08/WLX-4%20ee56ac0c96e34d6ca005df782840cd54.md | 50.000 |
| Drone%20Covers%20fe91ff98efef4ee58233886feac6b57b/DCD%204511c751938e458682483f647dbe596d.md | 1 |
| Energy%20Ammo%2035eb07f6e4704660acb8b47ce014fec2/EE-1%2068fceefbaf3c43909d2ce2cc6af0c17e.md | 500 |
| Rocket%20Ammo%20294a05bce70947eea43013d15afabf9d/TNC-130%20c1428b283d6846a5827b920c08cc6d19.md | 500 |

# ****Waves****

### **Wave 1**

20 [Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md)

10 [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md)

20 [Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md)

10 [Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md)

### **Wave 2**

20 [Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md)

20 [Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md)

### **Wave 3**

10 [Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md)

20 [Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md)

20 [Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md)

10 [Motron](Motron%20703f76f96c20484c85eedd4e590b3eda.md)

### **Wave 4**

10 [Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md)

10 [Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md)

10 [Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md)

2 [Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md)

### **Wave 5**

20 [Hyper Hydro](Hydro%2038f9d6a69b1c4cba83e5e820480636ff.md)

20 [Hyper Jenta](Jenta%206b238c04c24a458fa7485e23db813e48.md)

20 [Hyper Mali](Mali%2073004dfd8dc04292882b2282c519e0d8.md)

20 [Hyper Plarion](Plarion%207a0b01e4121940d0be4453b70bd4a91d.md)

### **Wave 6**

32 [Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md)

4 [Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md)

### **Wave 7**

20 [Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md)

20 [Hyper Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md)

20 [Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md)

20 [Hyper Raider](Raider%2049d85c720db14b09a19c6fd7a8b10415.md)

### **Wave 8**

20 [Bangoliour](Bangoliour%20feb26a5976de448b92d40ea38a0a36eb.md)

4 [Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md)

### **Wave 9**

20 [Vortex](Vortex%201def8df83c27449e9b924343ad8224f3.md)

10 [Hyper Vortex](Vortex%201def8df83c27449e9b924343ad8224f3.md)

2 [Hyper Zavientos](Zavientos%20a28be49b66384a719093c6336f20c866.md)

2 [Hyper Magmius](Magmius%20ca4841e944cc4776b860f60d632297e8.md)

### **Wave 10**

2 [Tark](Tark%209be4d13385314274a31a19a9c9e5af42.md)

1 Hyper Tark

1 [Ultra Tark](Tark%209be4d13385314274a31a19a9c9e5af42.md)