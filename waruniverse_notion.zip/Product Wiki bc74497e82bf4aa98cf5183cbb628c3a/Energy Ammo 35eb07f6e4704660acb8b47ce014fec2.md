# Energy Ammo

Owner: Artem AK

# **Electric Energy EE-1**

![**Electric Energy EE-1**](Energy%20Ammo%2035eb07f6e4704660acb8b47ce014fec2/Electronew.png)

**Electric Energy EE-1**

Basic component for extensions usage.

## ****Obtaining****

- Picking it up from a [bonus box](Boxes%2093ebc4bf4cc54122b18f3099e005047b.md). (Except for X-1, X-2 and X-7 maps.)
- Spinning (in [Star Missions](https://www.notion.so/Star-Missions-6c41438d8de04d0294a3d1af4705ec6f?pvs=21))
- Completing a quest and receiving it as a reward.
- Ammunition (in Shop )
- [Gold Market](https://www.notion.so/Game-Shop-7b59e521c1254374b5ab2cc15646bc14?pvs=21)
    - Standard Supply Package
    - Combat Supply Package
    - Rush Hour Supply Package

# **Nuclear Energy EN-702**

![**Nuclear Energy EN-702**](Energy%20Ammo%2035eb07f6e4704660acb8b47ce014fec2/Nuclearnew.png)

**Nuclear Energy EN-702**

Used for E-NB-01 explosion.

## Obtaining

- Picking it up from a [bonus box](Boxes%2093ebc4bf4cc54122b18f3099e005047b.md) during the Checkout event
- Spinning (in [Star Missions](https://www.notion.so/Star-Missions-6c41438d8de04d0294a3d1af4705ec6f?pvs=21))
- Completing a quest and receiving it as a reward.
- Ammunition (in Shop)
- [Gold Market](https://www.notion.so/Game-Shop-7b59e521c1254374b5ab2cc15646bc14?pvs=21)
    - Standard Supply Package

# **Magnetic Energy EM-AP-4**

![**Magnetic Energy EM-AP-4**](Energy%20Ammo%2035eb07f6e4704660acb8b47ce014fec2/Magneticnew.png)

**Magnetic Energy EM-AP-4**

Used for E-EMP-03.

## Obtaining

- Picking it up from a [bonus box](Boxes%2093ebc4bf4cc54122b18f3099e005047b.md) during the Checkout event
- Spinning (in [Star Missions](https://www.notion.so/Star-Missions-6c41438d8de04d0294a3d1af4705ec6f?pvs=21))
- Completing a quest and receiving it as a reward.
- Ammunition (in Shop )
- [Gold Market](https://www.notion.so/Game-Shop-7b59e521c1254374b5ab2cc15646bc14?pvs=21)
    - Standard Supply Package

# **Gravity Energy EG-88-3**

![**Gravity Energy EG-88-3**](Energy%20Ammo%2035eb07f6e4704660acb8b47ce014fec2/Gravitynew.png)

**Gravity Energy EG-88-3**

Used for generation of E-WS-02.

## Obtaining

- Picking it up from a [bonus box](Boxes%2093ebc4bf4cc54122b18f3099e005047b.md) during the Checkout event
- Spinning (in [Star Missions](https://www.notion.so/Star-Missions-6c41438d8de04d0294a3d1af4705ec6f?pvs=21))
- Completing a quest and receiving it as a reward.
- Ammunition (in Shop)
- [Gold Market](https://www.notion.so/Game-Shop-7b59e521c1254374b5ab2cc15646bc14?pvs=21)
    - Standard Supply Package

[EE-1](Energy%20Ammo%2035eb07f6e4704660acb8b47ce014fec2/EE-1%2068fceefbaf3c43909d2ce2cc6af0c17e.md)

[**EN-702**](Energy%20Ammo%2035eb07f6e4704660acb8b47ce014fec2/EN-702%2080f8d16883d34554aac2829e06367413.md)

[**EM-AP-4**](Energy%20Ammo%2035eb07f6e4704660acb8b47ce014fec2/EM-AP-4%205134b02b004b40109fc706a313fd98ab.md)

[**EG-88-3**](Energy%20Ammo%2035eb07f6e4704660acb8b47ce014fec2/EG-88-3%20d06b6834090649bfae7504551f306bef.md)