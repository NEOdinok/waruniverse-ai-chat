# War Of Factions

Owner: Artem AK

# **About the Event**

- **Location**: [X-2](Maps%20X-2%20162b702907e74e36bf9fc3149f51e7ff.md) map (Duel map)
- The last faction standing wins the round.
- The company with 3 wins - wins the event.
- The number of people participating in one round depends on the number of registered players.
- No player can fight before the start command. Fighting players will be disqualified. *(The disqualified player is kicked off the map and the player who opens the next ticket joins the event.)*

# **Progress**

- To participate, you must open a ticket on the [WU Tournament Discord](https://discord.gg/rmZHrWPn).
- You can open a ticket 30 minutes before the event starts. You must provide your ID, nickname, and faction on the ticket.
- After teleporting to the map, your ticket will be closed. At the end of each round, you must create a new ticket to join the event again.
- It is forbidden to move anywhere other than where we teleported you before we say start.
- The Start! command is given, and the event starts.

# **Rules**

- You can join the war with any ship [configuration](Shield%20Generators%20cf10852d8ed04fb08c52d19ff2b53284.md) you want.
- It is forbidden to use [invisibility](Extensions%20ad99098f7be6439b877727e8069749b1.md).
- It is forbidden to use spins on the event map.
- It is forbidden to run into the radiation zone.
- Players avoiding the fight for more than 30 seconds will be disqualified.
- It is forbidden to shoot administrators to get yellow health points during round preparation.

# **Reward**

Each player from the winning faction will receive 85,000 PLT.